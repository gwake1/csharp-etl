
-- XXX Grants

-- Creation, Modification, Maintenance History

---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this permission script
	
	SET NOCOUNT ON;

--Permissions Follow

	----------------
	-- user roles --
	----------------

	GRANT SELECT 							ON SSS.PPPXXX	TO udrReadOnlyUsers;
	GRANT SELECT, INSERT, UPDATE, DELETE	ON SSS.PPPXXX	TO udrSuperUsers;

	-----------------------
	-- application roles --
	-----------------------

	GRANT SELECT							ON SSS.PPPXXX	TO aprCustomerApps;
	GRANT SELECT, INSERT, UPDATE, DELETE	ON SSS.PPPXXX	TO aprCorporateApps;

GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Setting up permissions on SSS.PPPXXX', -1, -1);
	END

	ELSE --Things went well.. or no permissions to set
	BEGIN
		RAISERROR('Set permissions on SSS.PPPXXX', -1, -1);
		--RAISERROR('No permissions currently defined for SSS.PPPXXX', -1, -1);
	END
GO
