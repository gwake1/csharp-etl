
-- Convert_DataSourceKey_DataSourceNumber Grants

-- Creation, Modification, Maintenance History

---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this permission script
	
	SET NOCOUNT ON;

--Permissions Follow

	----------------
	-- user roles --
	----------------

	REVOKE EXECUTE 	ON Corporate.fnsConvert_DataSourceKey_DataSourceNumber	TO udrReadOnlyUsers;
	GRANT EXECUTE	ON Corporate.fnsConvert_DataSourceKey_DataSourceNumber	TO udrSuperUsers;

	-----------------------
	-- application roles --
	-----------------------

	GRANT EXECUTE	ON Corporate.fnsConvert_DataSourceKey_DataSourceNumber TO aprCustomerApps;
	GRANT EXECUTE 	ON Corporate.fnsConvert_DataSourceKey_DataSourceNumber TO aprCorporateApps;
GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Setting up permissions on Corporate.fnsConvert_DataSourceKey_DataSourceNumber', -1, -1);
	END

	ELSE --Things went well.. or no permissions to set
	BEGIN
		RAISERROR('Set permissions on Corporate.fnsConvert_DataSourceKey_DataSourceNumber', -1, -1);
		--RAISERROR('No permissions currently defined for Corporate.fnsConvert_DataSourceKey_DataSourceNumber', -1, -1);
	END
GO
