
-- lvwPartyV01 Grants

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this permission script
	
	SET NOCOUNT ON;

--Permissions Follow

	----------------
	-- user roles --
	----------------

	GRANT SELECT 							ON Corporate.lvwPartyV01	TO udrReadOnlyUsers;
	GRANT SELECT, INSERT, UPDATE, DELETE	ON Corporate.lvwPartyV01	TO udrSuperUsers;

	-----------------------
	-- application roles --
	-----------------------

	GRANT SELECT							ON Corporate.lvwPartyV01	TO aprCustomerApps;
	GRANT SELECT, INSERT, UPDATE, DELETE	ON Corporate.lvwPartyV01	TO aprCorporateApps;
GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Setting up permissions on Corporate.lvwPartyV01', -1, -1);
	END

	ELSE --Things went well.. or no permissions to set
	BEGIN
		RAISERROR('Set permissions on Corporate.lvwPartyV01', -1, -1);
		--RAISERROR('No permissions currently defined for Corporate.lvwPartyV01', -1, -1);
	END
GO
