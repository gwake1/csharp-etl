
-- Convert_DataSourceNumber_DataSourceKey Grants

-- Creation, Modification, Maintenance History

---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this permission script
	
	SET NOCOUNT ON;

--Permissions Follow

	----------------
	-- user roles --
	----------------

	REVOKE EXECUTE 	ON Corporate.fnsConvert_DataSourceNumber_DataSourceKey	TO udrReadOnlyUsers;
	GRANT EXECUTE	ON Corporate.fnsConvert_DataSourceNumber_DataSourceKey	TO udrSuperUsers;

	-----------------------
	-- application roles --
	-----------------------

	GRANT EXECUTE	ON Corporate.fnsConvert_DataSourceNumber_DataSourceKey TO aprCustomerApps;
	GRANT EXECUTE 	ON Corporate.fnsConvert_DataSourceNumber_DataSourceKey TO aprCorporateApps;
GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Setting up permissions on Corporate.fnsConvert_DataSourceNumber_DataSourceKey', -1, -1);
	END

	ELSE --Things went well.. or no permissions to set
	BEGIN
		RAISERROR('Set permissions on Corporate.fnsConvert_DataSourceNumber_DataSourceKey', -1, -1);
		--RAISERROR('No permissions currently defined for Corporate.fnsConvert_DataSourceNumber_DataSourceKey', -1, -1);
	END
GO
