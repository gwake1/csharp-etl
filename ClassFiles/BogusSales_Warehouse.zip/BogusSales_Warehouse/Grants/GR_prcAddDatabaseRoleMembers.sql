
-- prcAddDatabaseRoleMembers Grants

-- Creation, Modification, Maintenance History

---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2003.10.26	Jeffrey Schenk	Original creation of this permission script
	
	SET NOCOUNT ON

--Permissions Follow

	-- NONE

GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Setting up permissions on dbo.prcAddDatabaseRoleMembers', -1, -1)
	END

	ELSE --Things went well.. or no permissions to set
	BEGIN
		RAISERROR('Set permissions on dbo.prcAddDatabaseRoleMembers', -1, -1)
	END
GO
