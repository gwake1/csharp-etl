
USE master
GO

SET NOCOUNT ON

CREATE DATABASE BogusSales_Warehouse
CONTAINMENT = NONE
ON PRIMARY -- Carry system objects here
	(
	NAME = N'BogusSales_Warehouse_Sys',
	FILENAME = N'C:\DataSchenk\SqlData\BogusSales_Warehouse\BogusSales_Warehouse_Sys.mdf',
	SIZE = 15 MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 30%
	),

FILEGROUP BogusSales_Warehouse_Data -- Carry database objects here

	(
	NAME = N'BogusSales_Warehouse_Data',
	FILENAME = N'C:\DataSchenk\SqlData\BogusSales_Warehouse\BogusSales_Warehouse_Data.ndf',
	SIZE = 2000 MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 30%
	)

LOG ON -- Carry sequential log entries here
	(
	NAME = N'BogusSales_Warehouse_Log',
	FILENAME = N'C:\DataSchenk\SqlData\BogusSales_Warehouse\BogusSales_Warehouse_Log.ldf',
	SIZE = 500 MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 30%
	);
GO

ALTER DATABASE BogusSales_Warehouse 
	COLLATE SQL_Latin1_General_CP1_CI_AS; -- the default
GO

ALTER DATABASE BogusSales_Warehouse SET COMPATIBILITY_LEVEL = 130;
GO

ALTER DATABASE BogusSales_Warehouse
	MODIFY FILEGROUP BogusSales_Warehouse_Data DEFAULT;

GO

ALTER DATABASE BogusSales_Warehouse 
	SET TRUSTWORTHY ON; -- Support web calls from sql, etc.
GO

ALTER DATABASE BogusSales_Warehouse
	SET ENABLE_BROKER -- Activate Service Broker message deWarehousery
GO

ALTER DATABASE BogusSales_Warehouse SET ANSI_NULL_DEFAULT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET ANSI_NULLS ON; -- Force ON (as OFF is deprecated)
GO
ALTER DATABASE BogusSales_Warehouse SET ANSI_PADDING ON; -- Force ON (as OFF is deprecated)
GO
ALTER DATABASE BogusSales_Warehouse SET ANSI_WARNINGS ON; 
GO
ALTER DATABASE BogusSales_Warehouse SET ARITHABORT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_CLOSE OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_CREATE_STATISTICS ON; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_SHRINK OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_UPDATE_STATISTICS ON;
GO
ALTER DATABASE BogusSales_Warehouse SET CURSOR_CLOSE_ON_COMMIT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET CURSOR_DEFAULT GLOBAL; 
GO
ALTER DATABASE BogusSales_Warehouse SET CONCAT_NULL_YIELDS_NULL ON; -- Force ON (as OFF is deprecated)
GO
ALTER DATABASE BogusSales_Warehouse SET NUMERIC_ROUNDABORT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET QUOTED_IDENTIFIER OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET RECURSIVE_TRIGGERS OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET ENABLE_BROKER ;
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_UPDATE_STATISTICS_ASYNC OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET DATE_CORRELATION_OPTIMIZATION OFF; 
GO

-- Snapshot Isolation: http://msdn.microsoft.com/en-us/library/tcbchxcb(v=vs.110).aspx

ALTER DATABASE BogusSales_Warehouse SET ALLOW_SNAPSHOT_ISOLATION ON; -- Default is OFF, we want it ON
GO
ALTER DATABASE BogusSales_Warehouse SET READ_COMMITTED_SNAPSHOT OFF; -- Default is OFF, we'll turn it on as we need it.
GO

ALTER DATABASE BogusSales_Warehouse SET PARAMETERIZATION SIMPLE ;
GO
ALTER DATABASE BogusSales_Warehouse SET  READ_WRITE; 
GO
ALTER DATABASE BogusSales_Warehouse SET RECOVERY FULL; 
GO
ALTER DATABASE BogusSales_Warehouse SET  MULTI_USER; 
GO
ALTER DATABASE BogusSales_Warehouse SET PAGE_VERIFY TORN_PAGE_DETECTION; 
GO
ALTER DATABASE BogusSales_Warehouse SET DB_CHAINING OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET ANSI_NULL_DEFAULT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET ANSI_NULLS OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET ANSI_PADDING OFF;
GO
ALTER DATABASE BogusSales_Warehouse SET ANSI_WARNINGS ON;
GO
ALTER DATABASE BogusSales_Warehouse SET ARITHABORT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_CLOSE OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_CREATE_STATISTICS ON; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_SHRINK OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_UPDATE_STATISTICS ON; 
GO
ALTER DATABASE BogusSales_Warehouse SET CURSOR_CLOSE_ON_COMMIT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET CURSOR_DEFAULT GLOBAL; 
GO
ALTER DATABASE BogusSales_Warehouse SET CONCAT_NULL_YIELDS_NULL OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET NUMERIC_ROUNDABORT OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET QUOTED_IDENTIFIER OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET RECURSIVE_TRIGGERS OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET ENABLE_BROKER; 
GO
ALTER DATABASE BogusSales_Warehouse SET AUTO_UPDATE_STATISTICS_ASYNC OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET DATE_CORRELATION_OPTIMIZATION OFF; 
GO
ALTER DATABASE BogusSales_Warehouse SET TRUSTWORTHY ON; 
GO
ALTER DATABASE BogusSales_Warehouse SET PARAMETERIZATION SIMPLE;
GO
ALTER DATABASE BogusSales_Warehouse SET RECOVERY FULL; 
GO
ALTER DATABASE BogusSales_Warehouse SET MULTI_USER;
GO
ALTER DATABASE BogusSales_Warehouse SET PAGE_VERIFY CHECKSUM;
GO
ALTER DATABASE BogusSales_Warehouse SET DB_CHAINING OFF;
GO
ALTER DATABASE BogusSales_Warehouse SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE BogusSales_Warehouse SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
ALTER DATABASE BogusSales_Warehouse SET READ_WRITE;
GO

EXECUTE sys.sp_configure 'clr enabled', 1; -- Enable CLR Managed Code
RECONFIGURE;
GO

USE BogusSales_Warehouse;
GO

CREATE SCHEMA Corporate AUTHORIZATION dbo;
GO

CREATE SCHEMA Maintenance AUTHORIZATION dbo;
GO

