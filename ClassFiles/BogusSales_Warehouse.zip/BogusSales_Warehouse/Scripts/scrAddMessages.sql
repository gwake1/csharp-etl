
-- 50 + DbScriptor assigned Database Number (X) = XXxxx series numbers

sp_addmessage 64002, 10, 'prcAddDatabaseRoles -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64003, 16, 'prcAddDatabaseRoles -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO


sp_addmessage 64004, 10, 'prSyncProductDimension -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64005, 16, 'prSyncProductDimension -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO


sp_addmessage 64006, 10, 'prSyncShipperDimension -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64007, 16, 'prSyncShipperDimension -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO


sp_addmessage 64008, 10, 'prSyncSupplierDimension -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64009, 16, 'prSyncSupplierDimension -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO


sp_addmessage 64010, 10, 'prSyncBusinessUnitDimension -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64011, 16, 'prSyncBusinessUnitDimension -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO


sp_addmessage 64012, 10, 'prSyncStoreDimension -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64013, 16, 'prSyncStoreDimension -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO


sp_addmessage 64014, 10, 'prSyncPartyDimension -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64015, 16, 'prSyncPartyDimension -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO


sp_addmessage 64016, 10, 'prSyncDimensionTables -- Success(%d): %s',		NULL, FALSE, REPLACE
GO
sp_addmessage 64017, 16, 'prSyncDimensionTables -- Failure(%d): %s',		NULL, FALSE, REPLACE
GO