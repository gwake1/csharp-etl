

-- User-defined datatypes
-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2007.01.05	Jeffrey Schenk	Original creation of this procedure

SET NOCOUNT ON

USE BogusSales_Warehouse;

CREATE TYPE dbo.addressline FROM nvarchar(35) NOT NULL;		
CREATE TYPE dbo.businessunit_key FROM int NOT NULL;		
CREATE TYPE dbo.businessunitcode FROM nvarchar(10) NOT NULL;		
CREATE TYPE dbo.businessunitdesc FROM nvarchar(80) NOT NULL;		
CREATE TYPE dbo.cityortown FROM nvarchar(25) NOT NULL;		
CREATE TYPE dbo.comments FROM nvarchar(80) NULL;		
CREATE TYPE dbo.datasource_key FROM tinyint NOT NULL;		
CREATE TYPE dbo.datasourcename FROM nvarchar(40) NOT NULL;		
CREATE TYPE dbo.datasourcenumber FROM tinyint NOT NULL;		
CREATE TYPE dbo.date_key FROM int NOT NULL;	
CREATE TYPE dbo.ordernumber FROM int NOT NULL;	
CREATE TYPE dbo.organizationname FROM nvarchar(55) NOT NULL;			
CREATE TYPE dbo.orgsubtitle FROM nvarchar(80) NOT NULL;		
CREATE TYPE dbo.party_key FROM int NOT NULL;		
CREATE TYPE dbo.partyname FROM nvarchar(55) NOT NULL;		
CREATE TYPE dbo.partynumber FROM int NOT NULL;			
CREATE TYPE dbo.personname FROM nvarchar(65) NOT NULL;		
CREATE TYPE dbo.phonenumber FROM nvarchar(30) NOT NULL;			
CREATE TYPE dbo.product_key FROM int NOT NULL;		
CREATE TYPE dbo.pronunciation FROM nvarchar(255) NULL;		
CREATE TYPE dbo.provincename FROM nvarchar(30) NOT NULL;		
CREATE TYPE dbo.referencetypename FROM nvarchar(40) NULL;		
CREATE TYPE dbo.referralsource FROM nvarchar(80) NULL ;	
CREATE TYPE dbo.salesfact_key FROM int NOT NULL;		
CREATE TYPE dbo.scdhashtype	FROM varbinary(20) NOT NULL;	
CREATE TYPE dbo.shipper_key FROM int NOT NULL;		
CREATE TYPE dbo.shipperrank FROM tinyint NOT NULL;		
CREATE TYPE dbo.site_key FROM tinyint NOT NULL;		
CREATE TYPE dbo.sitecode FROM char(3) NULL;		
CREATE TYPE dbo.sitegeomarket FROM nvarchar(20) NOT NULL;		
CREATE TYPE dbo.sitegeoname FROM nvarchar(20) NOT NULL;		
CREATE TYPE dbo.sitename FROM nvarchar(15) NOT NULL;		
CREATE TYPE dbo.standarddesc FROM nvarchar(255) NOT NULL;		
CREATE TYPE dbo.store_key FROM int NOT NULL;		
CREATE TYPE dbo.storename FROM nvarchar(80) NOT NULL;		
CREATE TYPE dbo.storenumber FROM smallint NOT NULL;		
CREATE TYPE dbo.supplier_key FROM int NOT NULL;
CREATE TYPE dbo.supplierrank FROM tinyint NOT NULL;		
CREATE TYPE dbo.username FROM nvarchar(30) NULL;		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		
		
		
		
		

--CREATE TYPE dbo.addressline FROM nvarchar(35) NOT NULL;

--CREATE TYPE dbo.addressrole_id FROM tinyint NOT NULL;


--CREATE TYPE dbo.addressrolecode FROM nvarchar(10) NOT NULL;
--CREATE TYPE dbo.addressrolename FROM nvarchar(40) NOT NULL;
--CREATE TYPE dbo.addressroleseq FROM tinyint NOT NULL;
--CREATE TYPE dbo.businessunit_id FROM tinyint NOT NULL;
--CREATE TYPE dbo.businessunitcode FROM nvarchar(10) NOT NULL;
--CREATE TYPE dbo.businessunitdesc FROM nvarchar(80) NOT NULL;
--CREATE TYPE dbo.calendarday_id FROM int NOT NULL;
--CREATE TYPE dbo.cityortown FROM nvarchar(25) NOT NULL;
--CREATE TYPE dbo.countryname FROM nvarchar(45) NOT NULL;
--CREATE TYPE dbo.county FROM nvarchar(25) NOT NULL;
--CREATE TYPE dbo.datasource_id FROM tinyint NOT NULL;
--CREATE TYPE dbo.daynumber FROM int NOT NULL;
--CREATE TYPE dbo.directions FROM nvarchar(1000) NULL ;
--CREATE TYPE dbo.firstname FROM nvarchar(25) NULL;
--CREATE TYPE dbo.firstname_id FROM smallint NOT NULL;
--CREATE TYPE dbo.geoaddress_id FROM int NOT NULL;
--CREATE TYPE dbo.geoaddressname FROM nvarchar(55) NOT NULL;
--CREATE TYPE dbo.geoaddressnumber FROM int NOT NULL;
--CREATE TYPE dbo.lastname FROM nvarchar(40) NULL;
--CREATE TYPE dbo.middlename FROM nvarchar(15) NULL ;
--CREATE TYPE dbo.namesuffix FROM nvarchar(6) NULL ;
--CREATE TYPE dbo.nickname FROM nvarchar(15) NULL ;
--CREATE TYPE dbo.order_id FROM int NOT NULL;
--CREATE TYPE dbo.orderline_id FROM int NOT NULL;
--CREATE TYPE dbo.orderlinedesc FROM nvarchar(255) NOT NULL;
--CREATE TYPE dbo.orderlineseq FROM tinyint NOT NULL;
--CREATE TYPE dbo.orderlinestatus_id FROM tinyint NOT NULL;
--CREATE TYPE dbo.orderlinestatuscode FROM nvarchar(10) NOT NULL;
--CREATE TYPE dbo.orderlinestatusname FROM nvarchar(30) NOT NULL;
--CREATE TYPE dbo.orderlinestatusseq FROM tinyint NOT NULL;
--CREATE TYPE dbo.ordernumber FROM int NOT NULL;
--CREATE TYPE dbo.orderstatus_id FROM tinyint NOT NULL;
--CREATE TYPE dbo.orderstatuscode FROM nvarchar(10) NOT NULL;
--CREATE TYPE dbo.orderstatusname FROM nvarchar(30) NOT NULL;
--CREATE TYPE dbo.orderstatusseq FROM tinyint NOT NULL;
--CREATE TYPE dbo.orgabbreviation FROM nvarchar(12) NULL;
--CREATE TYPE dbo.organizationname FROM nvarchar(55) NOT NULL;
--CREATE TYPE dbo.orgsubtitle FROM nvarchar(80) NOT NULL;
--CREATE TYPE dbo.party_id FROM int NOT NULL;
--CREATE TYPE dbo.partynamenumber FROM tinyint NOT NULL;
--CREATE TYPE dbo.partynumber FROM int NOT NULL;
--CREATE TYPE dbo.partyxaddrxrole_id FROM integer NOT NULL;
--CREATE TYPE dbo.personaltitle FROM nvarchar(20) NULL;
--CREATE TYPE dbo.phonenumber FROM nvarchar(30) NOT NULL;
--CREATE TYPE dbo.postalcode FROM nvarchar(10) NOT NULL;
--CREATE TYPE dbo.product_id FROM int NOT NULL;
--CREATE TYPE dbo.productcategory_id FROM smallint NOT NULL;
CREATE TYPE dbo.productcategorycode FROM nvarchar(10) NOT NULL;
CREATE TYPE dbo.productcategoryname FROM nvarchar(80) NOT NULL;
CREATE TYPE dbo.productcode FROM nvarchar(15) NULL;
CREATE TYPE dbo.productname FROM nvarchar(40) NULL;
--CREATE TYPE dbo.productrank FROM tinyint NOT NULL;
--CREATE TYPE dbo.productxsupplier_id FROM int NOT NULL;
--CREATE TYPE dbo.pronunciation FROM nvarchar(255) NULL; --formerly 60
--CREATE TYPE dbo.provincename FROM nvarchar(30) NOT NULL;
--CREATE TYPE dbo.referralsource FROM nvarchar(80) NULL ;
--CREATE TYPE dbo.shipper_id FROM tinyint NOT NULL;
--CREATE TYPE dbo.shipperrank FROM tinyint NOT NULL;
--CREATE TYPE dbo.standarddesc FROM nvarchar(255) NOT NULL;
--CREATE TYPE dbo.store_id FROM smallint NOT NULL;
--CREATE TYPE dbo.storename FROM nvarchar(80) NOT NULL;
--CREATE TYPE dbo.storenumber FROM smallint NOT NULL;
--CREATE TYPE dbo.supplier_id FROM int NOT NULL;
--CREATE TYPE dbo.supplierrank FROM tinyint NOT NULL;
CREATE TYPE dbo.unitofissue FROM nvarchar(25) NOT NULL;
CREATE TYPE dbo.unitofissuedesc FROM nvarchar(80) NOT NULL;
--CREATE TYPE dbo.username FROM nvarchar(30) NULL;










