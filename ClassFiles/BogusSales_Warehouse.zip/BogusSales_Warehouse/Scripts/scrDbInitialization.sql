
-- Script Database Initialization

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------------

-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED

---------------	--------------	----------------------------------------------------
-- 2007.01.21	Jeffrey Schenk	Revamped old code I wrote years ago.

GO

	EXEC DataSchenk_Warehouse.Corporate.prcAddDatabaseRoleMembers

GO	
	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Failed to properly execute script scrDbInitialization', -1, -1)
	ELSE
		RAISERROR('Executed script scrDbInitialization', -1, -1)
GO