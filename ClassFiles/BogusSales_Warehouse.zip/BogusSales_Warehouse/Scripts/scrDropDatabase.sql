USE master

IF EXISTS(SELECT * FROM SysDatabases WHERE [name] = 'XXX')
DROP DATABASE XXX

GO