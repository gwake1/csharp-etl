
USE BogusSales_Warehouse
GO

-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncSupplierDimension')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncSupplierDimension;
GO

-- Procedure:	prcSyncSupplierDimension

-- Purpose:	This procedure synchronizes the Supplier Dimension table with it's source/sources.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.09	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncSupplierDimension
(
	@blnPreValidateInput	bit		= 1, 
	@intSuccessCode			int		= 64008,
	@intFailureCode			int		= 64009,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Synchronization Step One -- Update Existing Type 1 SCDs --
	-------------------------------------------------------------

	IF(1=1)
	BEGIN

		UPDATE Corporate.dimSupplier
		SET
			strVoicePhone = SourceSet.strVoicePhone, 			--	TYPE 1

			dteUpdatedDate			= CURRENT_TIMESTAMP,
			binHashSCDType1			= HASHBYTES('SHA1',ISNULL(SourceSet.strVoicePhone,''))

		FROM 
			(BogusSales_Live.Corporate.lvwSuppliersWideV01 AS SourceSet

			INNER JOIN Corporate.dimSupplier AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber)
			AND (
				HASHBYTES('SHA1', ISNULL(SourceSet.strVoicePhone,'')) <> DestinyTable.binHashSCDType1
				) --

			); -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Updated Type 1 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END

	-------------------------------------------------------------------------------
	-- Synchronization Step Two -- Insert New Records From Source System Table/s --
	-------------------------------------------------------------------------------

	IF(1=1)
	BEGIN

		INSERT INTO Corporate.dimSupplier
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 

				intPartyNumber,			--	TYPE 0
				strOrganizationName,	--	TYPE 2
				strOrgSubTitle,			--	TYPE 2
				strOrgComponentName,	--	TYPE 2
				intSupplierRank,		--	TYPE 2
				strSupplierRankNote,	--	TYPE 2
				strVoicePhone,			--	TYPE 1

				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag,
				binHashSCDType1, 
				binHashSCDType2,
				dteUpdatedDate
		)
		SELECT
				Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intPartyNumber, 		--	TYPE 0 not null
				SourceSet.strOrganizationName, 	--	TYPE 2 not null
				SourceSet.strOrgSubTitle, 		--	TYPE 2 null
				SourceSet.strOrgComponentName, 	--	TYPE 2 null
				SourceSet.intSupplierRank, 		--	TYPE 2 not null
				SourceSet.strSupplierRankNote, 	--	TYPE 2 null
				SourceSet.strVoicePhone, 		--	TYPE 1 null

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1', ISNULL(SourceSet.strVoicePhone,'')) AS binHashSCDType1,

				HASHBYTES('SHA1',

							 ISNULL(SourceSet.strOrganizationName,'')
							 + '|' + ISNULL(SourceSet.strOrgSubTitle,'')
							 + '|' + ISNULL(SourceSet.strOrgComponentName,'')
							 + '|' + CAST(ISNULL(SourceSet.intSupplierRank, '') AS VARCHAR(10))
							 + '|' + ISNULL(SourceSet.strSupplierRankNote,'')

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			(BogusSales_Live.Corporate.lvwSuppliersWideV01 AS SourceSet

			LEFT JOIN Corporate.dimSupplier AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber))

		WHERE
			(DestinyTable.intPartyNumber IS NULL)

		ORDER BY 
			SourceSet.intPartyNumber;

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added new dimension records: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END


	END -- Step Two


	---------------------------------------------------------------
	-- Synchronization Step Three -- Update Existing Type 2 SCDs --
	---------------------------------------------------------------
	IF(1=1)
	BEGIN

		-------------------------------------------------------
		-- Expire the (now historical) version of the record --
		-------------------------------------------------------

		DECLARE @ExpiredType2SCDs TABLE
		(
			intPartyNumber partynumber	NOT NULL
		);

		UPDATE Corporate.dimSupplier
		SET
			dteThruDate				= CURRENT_TIMESTAMP,
			blnCurrentFlag			= 0,
			dteUpdatedDate			= CURRENT_TIMESTAMP

		OUTPUT SourceSet.intPartyNumber INTO @ExpiredType2SCDs

		FROM 
			(BogusSales_Live.Corporate.lvwSuppliersWideV01 AS SourceSet

			INNER JOIN Corporate.dimSupplier AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber)
			AND (1 = DestinyTable.blnCurrentFlag)
			AND (
					HASHBYTES('SHA1',
	
							ISNULL(SourceSet.strOrganizationName,'')
								+ '|' + ISNULL(SourceSet.strOrgSubTitle,'')
								+ '|' + ISNULL(SourceSet.strOrgComponentName,'')
								+ '|' + CAST(ISNULL(SourceSet.intSupplierRank, '') AS VARCHAR(10))
								+ '|' + ISNULL(SourceSet.strSupplierRankNote,'')

						) <> DestinyTable.binHashSCDType2
				) --

			) -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Expired Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END


		--------------------------------------------------
		-- Create a new (Current) version of the record --
		--------------------------------------------------

		INSERT INTO Corporate.dimSupplier
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 

				intPartyNumber,			--	TYPE 0
				strOrganizationName,	--	TYPE 2
				strOrgSubTitle,			--	TYPE 2
				strOrgComponentName,	--	TYPE 2
				intSupplierRank,		--	TYPE 2
				strSupplierRankNote,	--	TYPE 2
				strVoicePhone,			--	TYPE 1

				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag,
				binHashSCDType1, 
				binHashSCDType2,
				dteUpdatedDate
		)
		SELECT
				100, --Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intPartyNumber, 		--	TYPE 0 not null
				SourceSet.strOrganizationName, 	--	TYPE 2 not null
				SourceSet.strOrgSubTitle, 		--	TYPE 2 null
				SourceSet.strOrgComponentName, 	--	TYPE 2 null
				SourceSet.intSupplierRank, 		--	TYPE 2 not null
				SourceSet.strSupplierRankNote, 	--	TYPE 2 null
				SourceSet.strVoicePhone, 		--	TYPE 1 null

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1', ISNULL(SourceSet.strVoicePhone,'')) AS binHashSCDType1,

				HASHBYTES('SHA1',

							ISNULL(SourceSet.strOrganizationName,'')
							 + '|' + ISNULL(SourceSet.strOrgSubTitle,'')
							 + '|' + ISNULL(SourceSet.strOrgComponentName,'')
							 + '|' + CAST(ISNULL(SourceSet.intSupplierRank, '') AS VARCHAR(10))
							 + '|' + ISNULL(SourceSet.strSupplierRankNote,'')

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			BogusSales_Live.Corporate.lvwSuppliersWideV01 AS SourceSet
		WHERE
			(SourceSet.intPartyNumber IN (SELECT intPartyNumber FROM @ExpiredType2SCDs));

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Added Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END -- Step Three
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncSupplierDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncSupplierDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncSupplierDimension', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncSupplierDimension', -1, -1);
	
GO
