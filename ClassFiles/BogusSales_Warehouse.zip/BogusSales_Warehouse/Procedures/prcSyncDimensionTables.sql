
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncDimensionTables')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncDimensionTables;
GO

-- Procedure:	prcSyncDimensionTables

-- Purpose:	This procedure does wonderful stuff.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncDimensionTables
(
	@blnPreValidateInput	bit		= 1, 
	@intSuccessCode			int		= 64016,
	@intFailureCode			int		= 64017,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	EXEC Corporate.prcSyncBusinessUnitDimension;
	EXEC Corporate.prcSyncPartyDimension;
	EXEC Corporate.prcSyncProductDimension;
	EXEC Corporate.prcSyncShipperDimension;
	EXEC Corporate.prcSyncStoreDimension;
	EXEC Corporate.prcSyncSupplierDimension;

	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncDimensionTables -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncDimensionTables -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncDimensionTables', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncDimensionTables', -1, -1);
	
GO
