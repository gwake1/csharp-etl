
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncBusinessUnitDimension')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncBusinessUnitDimension;
GO

--SELECT [name] + ',' FROM sys.columns WHERE ([object_id] = OBJECT_ID(N'Corporate.dimBusinessUnit')) ORDER BY column_id

-- Procedure:	prcSyncBusinessUnitDimension

-- Purpose:	This procedure synchronizes the BusinessUnit Dimension table with it's source/sources.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors

-- Execute Mode
		-- 1	TYPE 1 Upates
		-- 2	Add New Records
		-- 4	TYPE 2 Expire/Add


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.09	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncBusinessUnitDimension
(
	@intExecuteMode			tinyint	= 7,		-- Do everything by default
	@intSuccessCode			int		= 64010,
	@intFailureCode			int		= 64011,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Synchronization Step One -- Update Existing Type 1 SCDs --
	-------------------------------------------------------------

	IF((@intExecuteMode & 1) = 1) -- 0000 0001 then update 
	BEGIN

		UPDATE Corporate.dimBusinessUnit
		SET
			strBusinessUnitDesc	= SourceSet.strBusinessUnitDesc,		-- TYPE 1
			dteUpdatedDate			= CURRENT_TIMESTAMP,
			binHashSCDType1			= HASHBYTES('SHA1',
												 SourceSet.strBusinessUnitDesc
											) --

		FROM 
			(BogusSales_Live.Corporate.tblBusinessUnits AS SourceSet

			INNER JOIN Corporate.dimBusinessUnit AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.strBusinessUnitCode = DestinyTable.strBusinessUnitCode)
			AND (
					HASHBYTES('SHA1',
								SourceSet.strBusinessUnitDesc
							) <> DestinyTable.binHashSCDType1
				) --
			); -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Updated Type 1 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END

	-------------------------------------------------------------------------------
	-- Synchronization Step Two -- Insert New Records From Source System Table/s --
	-------------------------------------------------------------------------------

	IF((@intExecuteMode & 2) = 2) -- 0000 0010 then update 
	BEGIN

		INSERT INTO Corporate.dimBusinessUnit
		(
			intDataSource_KEY,
			intDataSourceNumber,
			strDataSourceName,
			strBusinessUnitCode,
			strBusinessUnitName,
			strBusinessUnitDesc,
			intOrganizationNumber,
			strOrganizationName,
			strParentUnitCode,
			strParentUnitName,
			intManagerNumber,
			strManagerName,
			dteFromDate,
			dteThruDate,
			blnCurrentFlag,
			binHashSCDType1,
			binHashSCDType2,
			dteUpdatedDate
		)
		SELECT
			Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
			1 AS intDataSourceNumber,
			'BogusSales_Live' AS strDataSourceName,

			SourceSet.strBusinessUnitCode,										-- Can Not be Changed!
			SourceSet.strBusinessUnitName,										-- TYPE 2
			SourceSet.strBusinessUnitDesc,										-- TYPE 1
			OrgNumber.intPartyNumber AS intOrganizationNumber,					-- TYPE 2
			Orgs.strOrganizationName,											-- TYPE 2
			Parent.strBusinessUnitCode AS strParentUnitCode,					-- TYPE 2
			Parent.strBusinessUnitName AS strParentUnitName,					-- TYPE 2
			ManagerNumber.intPartyNumber AS intManagerNumber,					-- TYPE 2
			Manager.strFirstName + ' ' + Manager.strLastName AS strManagerName,	-- TYPE 2

			CURRENT_TIMESTAMP AS dteFromDate, 
			NULL AS dteThruDate, 
			1 AS blnCurrentFlag, 

			HASHBYTES('SHA1',

						SourceSet.strBusinessUnitDesc

					) AS binHashSCDType1,

			HASHBYTES('SHA1',
	
						SourceSet.strBusinessUnitName
						+ '|' + CAST(OrgNumber.intPartyNumber AS nvarchar(10))
						+ '|' + Orgs.strOrganizationName
						+ '|' + Parent.strBusinessUnitCode
						+ '|' + Parent.strBusinessUnitName
						+ '|' + CAST(ManagerNumber.intPartyNumber AS nvarchar(10))
						+ '|' + Manager.strFirstName + ' ' + Manager.strLastName

					) AS binHashSCDType2,

			CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			((((((BogusSales_Live.Corporate.tblBusinessUnits AS SourceSet

			INNER JOIN BogusSales_Live.Corporate.tblOrganizations AS Orgs
			ON (SourceSet.intBusinessParty_ID = Orgs.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblParties AS OrgNumber
			ON (SourceSet.intBusinessParty_ID = OrgNumber.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblBusinessUnits AS Parent
			ON (SourceSet.intParentUnit_ID = Parent.intBusinessUnit_ID))

			INNER JOIN BogusSales_Live.Corporate.tblPersons AS Manager
			ON (SourceSet.intUnitManagerParty_ID = Manager.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblParties AS ManagerNumber
			ON (SourceSet.intUnitManagerParty_ID = ManagerNumber.intParty_ID))

			LEFT JOIN Corporate.dimBusinessUnit AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.strBusinessUnitCode = DestinyTable.strBusinessUnitCode))

		WHERE
			(DestinyTable.strBusinessUnitCode IS NULL)

		ORDER BY 
			SourceSet.strBusinessUnitCode;

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added new dimension records: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END


	END -- Step Two


	---------------------------------------------------------------
	-- Synchronization Step Three -- Update Existing Type 2 SCDs --
	---------------------------------------------------------------
	IF((@intExecuteMode & 4) = 4) -- 0000 0100 then update 
	BEGIN

	-------------------------------------------------------
	-- Expire the (now historical) version of the record --
	-------------------------------------------------------

		DECLARE @ExpiredType2SCDs TABLE
		(
			strBusinessUnitCode businessunitcode
		);

		UPDATE Corporate.dimBusinessUnit
		SET
			dteThruDate				= CURRENT_TIMESTAMP,
			blnCurrentFlag			= 0,
			dteUpdatedDate			= CURRENT_TIMESTAMP
						
		OUTPUT SourceSet.strBusinessUnitCode INTO @ExpiredType2SCDs

		FROM 
			((((((BogusSales_Live.Corporate.tblBusinessUnits AS SourceSet

			INNER JOIN BogusSales_Live.Corporate.tblOrganizations AS Orgs
			ON (SourceSet.intBusinessParty_ID = Orgs.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblParties AS OrgNumber
			ON (SourceSet.intBusinessParty_ID = OrgNumber.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblBusinessUnits AS Parent
			ON (SourceSet.intParentUnit_ID = Parent.intBusinessUnit_ID))

			INNER JOIN BogusSales_Live.Corporate.tblPersons AS Manager
			ON (SourceSet.intUnitManagerParty_ID = Manager.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblParties AS ManagerNumber
			ON (SourceSet.intUnitManagerParty_ID = ManagerNumber.intParty_ID))

			INNER JOIN Corporate.dimBusinessUnit AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.strBusinessUnitCode = DestinyTable.strBusinessUnitCode)
			AND (1 = DestinyTable.blnCurrentFlag)
			AND (
					HASHBYTES('SHA1',
	
							SourceSet.strBusinessUnitName
							+ '|' + CAST(OrgNumber.intPartyNumber AS nvarchar(10))
							+ '|' + Orgs.strOrganizationName
							+ '|' + Parent.strBusinessUnitCode
							+ '|' + Parent.strBusinessUnitName
							+ '|' + CAST(ManagerNumber.intPartyNumber AS nvarchar(10))
							+ '|' + Manager.strFirstName + ' ' + Manager.strLastName

						) <> DestinyTable.binHashSCDType2
				) --

			); -- Who's your momma?

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Expired Type 2 SCDs: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END

		--------------------------------------------------
		-- Create a new (Current) version of the record --
		--------------------------------------------------

		INSERT INTO Corporate.dimBusinessUnit
		(
			intDataSource_KEY,
			intDataSourceNumber,
			strDataSourceName,
			strBusinessUnitCode,
			strBusinessUnitName,
			strBusinessUnitDesc,
			intOrganizationNumber,
			strOrganizationName,
			strParentUnitCode,
			strParentUnitName,
			intManagerNumber,
			strManagerName,
			dteFromDate,
			dteThruDate,
			blnCurrentFlag,
			binHashSCDType1,
			binHashSCDType2,
			dteUpdatedDate
		)
		SELECT
			Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
			1 AS intDataSourceNumber,
			'BogusSales_Live' AS strDataSourceName,

			SourceSet.strBusinessUnitCode,										-- Can Not be Changed!
			SourceSet.strBusinessUnitName,										-- TYPE 2
			SourceSet.strBusinessUnitDesc,										-- TYPE 1
			OrgNumber.intPartyNumber AS intOrganizationNumber,					-- TYPE 2
			Orgs.strOrganizationName,											-- TYPE 2
			Parent.strBusinessUnitCode AS strParentUnitCode,					-- TYPE 2
			Parent.strBusinessUnitName AS strParentUnitName,					-- TYPE 2
			ManagerNumber.intPartyNumber AS intManagerNumber,					-- TYPE 2
			Manager.strFirstName + ' ' + Manager.strLastName AS strManagerName,	-- TYPE 2

			CURRENT_TIMESTAMP AS dteFromDate, 
			NULL AS dteThruDate, 
			1 AS blnCurrentFlag, 

			HASHBYTES('SHA1',

						SourceSet.strBusinessUnitDesc

					) AS binHashSCDType1,

			HASHBYTES('SHA1',
	
						SourceSet.strBusinessUnitName
						+ '|' + CAST(OrgNumber.intPartyNumber AS nvarchar(10))
						+ '|' + Orgs.strOrganizationName
						+ '|' + Parent.strBusinessUnitCode
						+ '|' + Parent.strBusinessUnitName
						+ '|' + CAST(ManagerNumber.intPartyNumber AS nvarchar(10))
						+ '|' + Manager.strFirstName + ' ' + Manager.strLastName

					) AS binHashSCDType2,

			CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			(((((BogusSales_Live.Corporate.tblBusinessUnits AS SourceSet

			INNER JOIN BogusSales_Live.Corporate.tblOrganizations AS Orgs
			ON (SourceSet.intBusinessParty_ID = Orgs.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblParties AS OrgNumber
			ON (SourceSet.intBusinessParty_ID = OrgNumber.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblBusinessUnits AS Parent
			ON (SourceSet.intParentUnit_ID = Parent.intBusinessUnit_ID))

			INNER JOIN BogusSales_Live.Corporate.tblPersons AS Manager
			ON (SourceSet.intUnitManagerParty_ID = Manager.intParty_ID))

			INNER JOIN BogusSales_Live.Corporate.tblParties AS ManagerNumber
			ON (SourceSet.intUnitManagerParty_ID = ManagerNumber.intParty_ID))

		WHERE
			(SourceSet.strBusinessUnitCode IN(SELECT strBusinessUnitCode FROM @ExpiredType2SCDs))
		ORDER BY 
			SourceSet.strBusinessUnitCode;
			
			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Added Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END -- Step Three
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncBusinessUnitDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncBusinessUnitDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncBusinessUnitDimension', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncBusinessUnitDimension', -1, -1);
	
GO
