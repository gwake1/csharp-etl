
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcAddDatabaseRoleMembers')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcAddDatabaseRoleMembers
GO

--Procedure:	prcAddDatabaseRoleMembers

--Purpose:	This procedure adds database members as needed to database roles

--ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2003.10.26	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcAddDatabaseRoleMembers
 
	@intSuccessCode			int		= 60002,
	@intFailureCode			int		= 60003,
	@blnDebugMode			bit		= 0

WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)
	DECLARE @intRowCount		int
	DECLARE @intIdentityValue	int
	DECLARE @intErrorBuffer		int
	DECLARE @intReturnStatus	int
	DECLARE @intReturnValue		int
	DECLARE @intErrorCode		int

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SELECT
		@intErrorBuffer		= 0,
		@intReturnValue		= 0,
		@strMessage		= ''

	-----------------------------------
	-- Add database role memberships --
	-----------------------------------

	EXECUTE @intReturnStatus = sys.sp_addrolemember
			@rolename 	= N'udrSuperUsers', 
			@membername	= N'CorpSuperUsers'

	SELECT @intErrorBuffer = (@intErrorBuffer | @intReturnStatus)
	
		EXECUTE @intReturnStatus = sys.sp_addrolemember
			@rolename 	= N'db_owner', 
			@membername	= N'CorpSuperUsers'

	SELECT @intErrorBuffer = (@intErrorBuffer | @intReturnStatus)		

	-----------------------------------------
	-- Pass out accumulated errors, if any --
	-----------------------------------------

	SELECT @intReturnValue = @intErrorBuffer
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	------------------------------------------------------------------   

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	------------------------------------------------------
	-- Return Success / Failure Knowledge to the Caller --
	------------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT Event Log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG
		ELSE
			RAISERROR('prcAddDatabaseRoleMembers -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage)
		ELSE
			RAISERROR('prcAddDatabaseRoleMembers -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage)
	END

	RETURN(@intReturnValue)
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcAddDatabaseRoleMembers', -1, -1)
	ELSE
		RAISERROR('Created Procedure Corporate.prcAddDatabaseRoleMembers', -1, -1)
	
GO
