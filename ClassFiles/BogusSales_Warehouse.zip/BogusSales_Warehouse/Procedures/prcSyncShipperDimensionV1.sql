
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncShipperDimension')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncShipperDimension;
GO

-- Procedure:	prcSyncShipperDimension

-- Purpose:	This procedure synchronizes the Shipper Dimension table with it's source/sources.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors

-- Execute Mode
		-- 1	TYPE 1 Upates
		-- 2	Add New Records
		-- 4	TYPE 2 Expire/Add


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.10	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncShipperDimension
(
	@intExecuteMode			tinyint	= 7,		-- Do everything by default
	@intSuccessCode			int		= 64006,
	@intFailureCode			int		= 64007,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;
	DECLARE @intDataSourceKey	datasource_key	= 0;

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	SET @intDataSourceKey = Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1);

	-------------------------------------------------------------
	-- Synchronization Step One -- Update Existing Type 1 SCDs --
	-------------------------------------------------------------

	IF((@intExecuteMode & 1) = 1) -- 0000 0001 then update 
	BEGIN

		UPDATE Corporate.dimShipper
		SET
			strVoicePhone		= SourceSet.strVoicePhone,		-- TYPE 1
			dteUpdatedDate		= CURRENT_TIMESTAMP,
			binHashSCDType1		= HASHBYTES('SHA1',ISNULL(SourceSet.strVoicePhone, ''))

		FROM 
			(BogusSales_Live.Corporate.lvwShippersWideV01 AS SourceSet

			INNER JOIN Corporate.dimShipper AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber)
			AND (HASHBYTES('SHA1',ISNULL(SourceSet.strVoicePhone, '')) <> DestinyTable.binHashSCDType1) 

			); -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Updated Type 1 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END

	-------------------------------------------------------------------------------
	-- Synchronization Step Two -- Insert New Records From Source System Table/s --
	-------------------------------------------------------------------------------

	IF((@intExecuteMode & 2) = 2) -- 0000 0010 then update 
	BEGIN

		INSERT INTO Corporate.dimShipper
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 

				intPartyNumber, 
				strOrganizationName, 
				strOrgSubTitle, 
				strOrgComponentName, 
				intShipperRank, 
				strShipperRankNote, 
				strVoicePhone, 

				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				@intDataSourceKey, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intPartyNumber,			-- Durable Key, can't change it. 
				SourceSet.strOrganizationName,		-- TYPE 2	
				SourceSet.strOrgSubTitle, 			-- TYPE 2
				SourceSet.strOrgComponentName,		-- TYPE 2
				SourceSet.intShipperRank, 			-- TYPE 2
				SourceSet.strShipperRankNote, 		-- TYPE 2
				SourceSet.strVoicePhone, 			-- TYPE 1

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',ISNULL(SourceSet.strVoicePhone, '')) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strOrganizationName
							+ '|' + ISNULL(SourceSet.strOrgSubTitle, '')
							+ '|' + ISNULL(SourceSet.strOrgComponentName, '')
							+ '|' + CAST(SourceSet.intShipperRank AS nvarchar(10))
							+ '|' + ISNULL(SourceSet.strShipperRankNote, '')

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			(BogusSales_Live.Corporate.lvwShippersWideV01 AS SourceSet

			LEFT JOIN Corporate.dimShipper AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber)) -- Hoakie, I know.

		WHERE
			(DestinyTable.intPartyNumber IS NULL)

		ORDER BY 
			SourceSet.intPartyNumber;

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added new dimension records: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END


	END -- Step Two


	---------------------------------------------------------------
	-- Synchronization Step Three -- Update Existing Type 2 SCDs --
	---------------------------------------------------------------
	IF((@intExecuteMode & 4) = 4) -- 0000 0100 then update 
	BEGIN

		--------------------------------------------------
		-- Create a new (Current) version of the record --
		--------------------------------------------------

		INSERT INTO Corporate.dimShipper
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 

				intPartyNumber, 
				strOrganizationName, 
				strOrgSubTitle, 
				strOrgComponentName, 
				intShipperRank, 
				strShipperRankNote, 
				strVoicePhone, 

				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				@intDataSourceKey, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intPartyNumber,			-- Durable Key, can't change it. 
				SourceSet.strOrganizationName,		-- TYPE 2	
				SourceSet.strOrgSubTitle, 			-- TYPE 2
				SourceSet.strOrgComponentName,		-- TYPE 2
				SourceSet.intShipperRank, 			-- TYPE 2
				SourceSet.strShipperRankNote, 		-- TYPE 2
				SourceSet.strVoicePhone, 			-- TYPE 1

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',ISNULL(SourceSet.strVoicePhone, '')) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strOrganizationName
							+ '|' + ISNULL(SourceSet.strOrgSubTitle, '')
							+ '|' + ISNULL(SourceSet.strOrgComponentName, '')
							+ '|' + CAST(SourceSet.intShipperRank AS nvarchar(10))
							+ '|' + ISNULL(SourceSet.strShipperRankNote, '')

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM	(

				-------------------------------------------------------
				-- Expire the (now historical) version of the record --
				-------------------------------------------------------

					UPDATE Corporate.dimShipper
					SET
						dteThruDate				= CURRENT_TIMESTAMP,
						blnCurrentFlag			= 0,
						dteUpdatedDate			= CURRENT_TIMESTAMP

					OUTPUT SourceSet.*

					FROM 
						(BogusSales_Live.Corporate.lvwShippersWideV01 AS SourceSet

						INNER JOIN Corporate.dimShipper AS DestinyTable
						ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
						AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber)
						AND (1 = DestinyTable.blnCurrentFlag)
						AND (
								HASHBYTES('SHA1',
	
							SourceSet.strOrganizationName
							+ '|' + ISNULL(SourceSet.strOrgSubTitle, '')
							+ '|' + ISNULL(SourceSet.strOrgComponentName, '')
							+ '|' + CAST(SourceSet.intShipperRank AS nvarchar(10))
							+ '|' + ISNULL(SourceSet.strShipperRankNote, '')

						) <> DestinyTable.binHashSCDType2
							) --

						) -- Who's your momma?

				) AS SourceSet

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Expired/Added Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END -- Step Three
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncShipperDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncShipperDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncShipperDimension', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncShipperDimension', -1, -1);
	
GO
