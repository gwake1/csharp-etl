
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncProductDimension')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncProductDimension;
GO

-- Procedure:	prcSyncProductDimension

-- Purpose:	This procedure synchronizes the Product Dimension table with it's source/sources.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.09	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncProductDimension
(
	@blnPreValidateInput	bit		= 1, 
	@intSuccessCode			int		= 64004,
	@intFailureCode			int		= 64005,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Synchronization Step One -- Update Existing Type 1 SCDs --
	-------------------------------------------------------------

	IF(1=1)
	BEGIN

		UPDATE Corporate.dimProduct
		SET
			strProductCategoryCode	= SourceSet.strProductCategoryCode,		-- TYPE 1
			strProductCategoryName	= SourceSet.strProductCategoryName,		-- TYPE 1
			strProductCategoryDesc	= SourceSet.strProductCategoryDesc,		-- TYPE 1
			strUnitOfIssueDesc		= SourceSet.strUnitOfIssueDesc,			-- TYPE 1
			dteUpdatedDate			= CURRENT_TIMESTAMP,
			binHashSCDType1			= HASHBYTES('SHA1',
												 SourceSet.strProductCategoryCode
												 + '|' + SourceSet.strProductCategoryName
												 + '|' + ISNULL(SourceSet.strProductCategoryDesc, '')
												 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')
											) --

		FROM 
			(BogusSales_Live.Corporate.lvwProductsWideV01 AS SourceSet

			INNER JOIN Corporate.dimProduct AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.strProductCode = DestinyTable.strProductCode)
			AND (
			
					HASHBYTES('SHA1',

									 SourceSet.strProductCategoryCode
									 + '|' + SourceSet.strProductCategoryName
									 + '|' + ISNULL(SourceSet.strProductCategoryDesc, '')
									 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')

								) <> DestinyTable.binHashSCDType1
				) --

			); -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Updated Type 1 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END

	-------------------------------------------------------------------------------
	-- Synchronization Step Two -- Insert New Records From Source System Table/s --
	-------------------------------------------------------------------------------

	IF(1=1)
	BEGIN

		INSERT INTO Corporate.dimProduct
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				strProductCode, 
				strProductName, 
				strProductCategoryCode, 
				strProductCategoryName, 
				strProductCategoryDesc, 
				strProductDesc, 
				strUnitOfIssue, 
				strUnitOfIssueDesc,  
				curUnitPrice, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.strProductCode,				-- TYPE 0
				SourceSet.strProductName,				-- TYPE 0
				SourceSet.strProductCategoryCode,		-- TYPE 1
				SourceSet.strProductCategoryName,		-- TYPE 1
				SourceSet.strProductCategoryDesc,		-- TYPE 1
				SourceSet.strProductDesc,				-- TYPE 2
				SourceSet.strUnitOfIssue,				-- TYPE 0
				SourceSet.strUnitOfIssueDesc,			-- TYPE 1
				SourceSet.curUnitPrice,					-- TYPE 2

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',

							 SourceSet.strProductCategoryCode
							 + '|' + SourceSet.strProductCategoryName
							 + '|' + ISNULL(SourceSet.strProductCategoryDesc, '')
							 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')

						) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strProductDesc
							+ '|' + CAST(SourceSet.curUnitPrice AS nvarchar(10))

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			(BogusSales_Live.Corporate.lvwProductsWideV01 AS SourceSet

			LEFT JOIN Corporate.dimProduct AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.strProductCode = DestinyTable.strProductCode))

		WHERE
			(DestinyTable.strProductCode IS NULL)

		ORDER BY 
			SourceSet.strProductCode;

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added new dimension records: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END


	END -- Step Two


	---------------------------------------------------------------
	-- Synchronization Step Three -- Update Existing Type 2 SCDs --
	---------------------------------------------------------------
	IF(1=1)
	BEGIN


		-------------------------------------------------------
		-- Expire the (now historical) version of the record --
		-------------------------------------------------------


			DECLARE @ExpiredType2SCDs TABLE
			(
				strProductCode productcode	NOT NULL
			);

			UPDATE Corporate.dimProduct
			SET
				dteThruDate				= CURRENT_TIMESTAMP,
				blnCurrentFlag			= 0,
				dteUpdatedDate			= CURRENT_TIMESTAMP

			OUTPUT SourceSet.strProductCode INTO @ExpiredType2SCDs

			FROM 
				(BogusSales_Live.Corporate.lvwProductsWideV01 AS SourceSet

				INNER JOIN Corporate.dimProduct AS DestinyTable
				ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
				AND (SourceSet.strProductCode = DestinyTable.strProductCode)
				AND (1 = DestinyTable.blnCurrentFlag)
				AND (
						HASHBYTES('SHA1',
	
								SourceSet.strProductDesc
								+ '|' + CAST(SourceSet.curUnitPrice AS nvarchar(10))

							) <> DestinyTable.binHashSCDType2
					) --

				) -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Expired Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END


		--------------------------------------------------
		-- Create a new (Current) version of the record --
		--------------------------------------------------

		INSERT INTO Corporate.dimProduct
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				strProductCode, 
				strProductName, 
				strProductCategoryCode, 
				strProductCategoryName, 
				strProductCategoryDesc, 
				strProductDesc, 
				strUnitOfIssue, 
				strUnitOfIssueDesc,  
				curUnitPrice, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				100, --Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.strProductCode,				-- TYPE 0
				SourceSet.strProductName,				-- TYPE 0
				SourceSet.strProductCategoryCode,		-- TYPE 1
				SourceSet.strProductCategoryName,		-- TYPE 1
				SourceSet.strProductCategoryDesc,		-- TYPE 1
				SourceSet.strProductDesc,				-- TYPE 2
				SourceSet.strUnitOfIssue,				-- TYPE 0
				SourceSet.strUnitOfIssueDesc,			-- TYPE 1
				SourceSet.curUnitPrice,					-- TYPE 2

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',

							 SourceSet.strProductCategoryCode
							 + '|' + SourceSet.strProductCategoryName
							 + '|' + ISNULL(SourceSet.strProductCategoryDesc, '')
							 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')

						) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strProductDesc
							+ '|' + CAST(SourceSet.curUnitPrice AS nvarchar(10))

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			BogusSales_Live.Corporate.lvwProductsWideV01 AS SourceSet
		WHERE
			(SourceSet.strProductCode IN (SELECT strProductCode FROM @ExpiredType2SCDs));

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Added Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END -- Step Three
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncProductDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncProductDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncProductDimension', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncProductDimension', -1, -1);
	
GO
