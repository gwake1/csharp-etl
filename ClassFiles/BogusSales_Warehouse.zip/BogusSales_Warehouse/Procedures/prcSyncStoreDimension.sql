
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncStoreDimension')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncStoreDimension;
GO

-- Procedure:	prcSyncStoreDimension

-- Purpose:	This procedure synchronizes the Store Dimension table with it's source/sources.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors

-- Execute Mode
		-- 1	TYPE 1 Upates
		-- 2	Add New Records
		-- 4	TYPE 2 Expire/Add


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.09	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncStoreDimension
(
	@intExecuteMode			tinyint	= 7,		-- Do everything by default
	@intSuccessCode			int		= 64012,
	@intFailureCode			int		= 64013,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;
	DECLARE @intDataSourceKey	int				= Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1);

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Synchronization Step One -- Update Existing Type 1 SCDs --
	-------------------------------------------------------------

	IF((@intExecuteMode & 1) = 1) -- 0000 0001 then update 
	BEGIN

		UPDATE Corporate.dimStore
		SET
			strDoingBusinessAsName	= SourceSet.strDoingBusinessAsName,		-- TYPE 1
			strAddressLine1			= SourceSet.strAddressLine1,			-- TYPE 1
			strCity					= SourceSet.strCity,					-- TYPE 1
			strProvince				= SourceSet.strProvince,				-- TYPE 1
			strVoicePhone			= SourceSet.strVoicePhone,				-- TYPE 1
			dteUpdatedDate			= CURRENT_TIMESTAMP,
			binHashSCDType1			= HASHBYTES('SHA1',
													 SourceSet.strDoingBusinessAsName
													 + '|' + SourceSet.strAddressLine1
													 + '|' + SourceSet.strCity
													 + '|' + ISNULL(SourceSet.strProvince, '')
													 + '|' + ISNULL(SourceSet.strVoicePhone, '')
												) --

		FROM 
			(BogusSales_Live.Corporate.lvwStoresWideV01 AS SourceSet

			INNER JOIN Corporate.dimStore AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intStoreNumber = DestinyTable.intStoreNumber)
			AND (
					HASHBYTES('SHA1',

								 SourceSet.strDoingBusinessAsName
								 + '|' + SourceSet.strAddressLine1
								 + '|' + SourceSet.strCity
								 + '|' + ISNULL(SourceSet.strProvince, '')
								 + '|' + ISNULL(SourceSet.strVoicePhone, '')

							) <> DestinyTable.binHashSCDType1
				) --

			); -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Updated Type 1 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END

	-------------------------------------------------------------------------------
	-- Synchronization Step Two -- Insert New Records From Source System Table/s --
	-------------------------------------------------------------------------------

	IF((@intExecuteMode & 2) = 2) -- 0000 0010 then update 
	BEGIN

		INSERT INTO Corporate.dimStore
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				intStoreNumber, 
				strStoreName, 
				strDoingBusinessAsName, 
				strBusinessUnitCode, 
				strBusinessUnitName, 
				strStoreOrgName, 
				strAddressLine1, 
				strCity, 
				strProvince, 
				strManagerName, 
				strVoicePhone, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				@intDataSourceKey AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intStoreNumber,			-- Can Not be Changed!
				SourceSet.strStoreName,				-- TYPE 2
				SourceSet.strDoingBusinessAsName,	-- TYPE 1
				SourceSet.strBusinessUnitCode,		-- TYPE 2
				SourceSet.strBusinessUnitName,		-- TYPE 2
				SourceSet.strStoreOrgName,			-- TYPE 2
				SourceSet.strAddressLine1,			-- TYPE 1
				SourceSet.strCity,					-- TYPE 1
				SourceSet.strProvince,				-- TYPE 1
				SourceSet.strManagerName,			-- TYPE 2
				SourceSet.strVoicePhone,			-- TYPE 1

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',

							 SourceSet.strDoingBusinessAsName
							 + '|' + SourceSet.strAddressLine1
							 + '|' + SourceSet.strCity
							 + '|' + ISNULL(SourceSet.strProvince, '')
							 + '|' + ISNULL(SourceSet.strVoicePhone, '')

						) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strStoreName
							+ '|' + SourceSet.strBusinessUnitCode
							+ '|' + SourceSet.strBusinessUnitName
							+ '|' + SourceSet.strStoreOrgName
							+ '|' + SourceSet.strManagerName

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			(BogusSales_Live.Corporate.lvwStoresWideV01 AS SourceSet

			LEFT JOIN Corporate.dimStore AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intStoreNumber = DestinyTable.intStoreNumber))

		WHERE
			(DestinyTable.intStoreNumber IS NULL)

		ORDER BY 
			SourceSet.intStoreNumber;

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added new dimension records: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END


	END -- Step Two


	---------------------------------------------------------------
	-- Synchronization Step Three -- Update Existing Type 2 SCDs --
	---------------------------------------------------------------
	IF((@intExecuteMode & 4) = 4) -- 0000 0100 then update 
	BEGIN

	-------------------------------------------------------
	-- Expire the (now historical) version of the record --
	-------------------------------------------------------

		DECLARE @ExpiredType2SCDs TABLE
		(
			intStoreNumber storenumber
		);

		UPDATE Corporate.dimStore
		SET
			dteThruDate				= CURRENT_TIMESTAMP,
			blnCurrentFlag			= 0,
			dteUpdatedDate			= CURRENT_TIMESTAMP

		OUTPUT SourceSet.intStoreNumber INTO @ExpiredType2SCDs

		FROM 
			(BogusSales_Live.Corporate.lvwStoresWideV01 AS SourceSet

			INNER JOIN Corporate.dimStore AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intStoreNumber = DestinyTable.intStoreNumber)
			AND (1 = DestinyTable.blnCurrentFlag)
			AND (
					HASHBYTES('SHA1',
	
								SourceSet.strStoreName
								+ '|' + SourceSet.strBusinessUnitCode
								+ '|' + SourceSet.strBusinessUnitName
								+ '|' + SourceSet.strStoreOrgName
								+ '|' + SourceSet.strManagerName

							) <> DestinyTable.binHashSCDType2
				) --

			); -- Who's your momma?

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Expired Type 2 SCDs: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END

		--------------------------------------------------
		-- Create a new (Current) version of the record --
		--------------------------------------------------

		INSERT INTO Corporate.dimStore
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				intStoreNumber, 
				strStoreName, 
				strDoingBusinessAsName, 
				strBusinessUnitCode, 
				strBusinessUnitName, 
				strStoreOrgName, 
				strAddressLine1, 
				strCity, 
				strProvince, 
				strManagerName, 
				strVoicePhone, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				@intDataSourceKey AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intStoreNumber,			-- Can Not be Changed!
				SourceSet.strStoreName,				-- TYPE 2
				SourceSet.strDoingBusinessAsName,	-- TYPE 1
				SourceSet.strBusinessUnitCode,		-- TYPE 2
				SourceSet.strBusinessUnitName,		-- TYPE 2
				SourceSet.strStoreOrgName,			-- TYPE 2
				SourceSet.strAddressLine1,			-- TYPE 1
				SourceSet.strCity,					-- TYPE 1
				SourceSet.strProvince,				-- TYPE 1
				SourceSet.strManagerName,			-- TYPE 2
				SourceSet.strVoicePhone,			-- TYPE 1

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',

							 SourceSet.strDoingBusinessAsName
							 + '|' + SourceSet.strAddressLine1
							 + '|' + SourceSet.strCity
							 + '|' + ISNULL(SourceSet.strProvince, '')
							 + '|' + ISNULL(SourceSet.strVoicePhone, '')

						) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strStoreName
							+ '|' + SourceSet.strBusinessUnitCode
							+ '|' + SourceSet.strBusinessUnitName
							+ '|' + SourceSet.strStoreOrgName
							+ '|' + SourceSet.strManagerName

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM	
			BogusSales_Live.Corporate.lvwStoresWideV01 AS SourceSet
		WHERE
			(SourceSet.intStoreNumber IN(SELECT intStoreNumber FROM @ExpiredType2SCDs));

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Added Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END -- Step Three
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncStoreDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncStoreDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncStoreDimension', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncStoreDimension', -1, -1);
	
GO
