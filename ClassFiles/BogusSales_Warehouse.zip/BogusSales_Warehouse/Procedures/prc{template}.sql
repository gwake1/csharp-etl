
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'SSS.prcXXX')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE SSS.prcXXX;
GO

-- Procedure:	prcXXX

-- Purpose:	This procedure does wonderful stuff.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE SSS.prcXXX
(
	@blnPreValidateInput	bit		= 1, 
	@intSuccessCode			int		= 53ZZZ,
	@intFailureCode			int		= 53ZZZ,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;



	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcXXX -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcXXX -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure SSS.prcXXX', -1, -1);
	ELSE
		RAISERROR('Created Procedure SSS.prcXXX', -1, -1);
	
GO
