
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncXXXDimension')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncXXXDimension;
GO

-- Procedure:	prcSyncXXXDimension

-- Purpose:	This procedure synchronizes the XXX Dimension table with it's source/sources.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors


-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncXXXDimension
(
	@blnPreValidateInput	bit		= 1, 
	@intSuccessCode			int		= ZZZZZ,
	@intFailureCode			int		= ZZZZZ,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Synchronization Step One -- Update Existing Type 1 SCDs --
	-------------------------------------------------------------

	IF(1=1)
	BEGIN

		UPDATE Corporate.dimXXX
		SET
			strVVV1	= SourceSet.strVVV1,		-- TYPE 1
			strVVV2	= SourceSet.strVVV2,		-- TYPE 1
			strXXXCategoryDesc	= SourceSet.strXXXCategoryDesc,		-- TYPE 1
			strUnitOfIssueDesc		= SourceSet.strUnitOfIssueDesc,			-- TYPE 1
			dteUpdatedDate			= CURRENT_TIMESTAMP,
			binHashSCDType1			= HASHBYTES('SHA1',
												 SourceSet.strVVV1
												 + '|' + SourceSet.strVVV2
												 + '|' + ISNULL(SourceSet.strXXXCategoryDesc, '')
												 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')
											) --

		FROM 
			(BogusSales_Live.Corporate.lvwXXXsWideV01 AS SourceSet

			INNER JOIN Corporate.dimXXX AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.strXXXCode = DestinyTable.strXXXCode)
			AND (
			
					HASHBYTES('SHA1',

									 SourceSet.strVVV1
									 + '|' + SourceSet.strVVV2
									 + '|' + ISNULL(SourceSet.strXXXCategoryDesc, '')
									 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')

								) <> DestinyTable.binHashSCDType1
				) --

			); -- Who's your momma?

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Updated Type 1 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END

	-------------------------------------------------------------------------------
	-- Synchronization Step Two -- Insert New Records From Source System Table/s --
	-------------------------------------------------------------------------------

	IF(1=1)
	BEGIN

		INSERT INTO Corporate.dimXXX
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				strXXXCode, 
				strXXXName, 
				strVVV1, 
				strVVV2, 
				strXXXCategoryDesc, 
				strXXXDesc, 
				strUnitOfIssue, 
				strUnitOfIssueDesc,  
				curUnitPrice, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.strXXXCode,				-- TYPE 0
				SourceSet.strXXXName,				-- TYPE 0
				SourceSet.strVVV1,		-- TYPE 1
				SourceSet.strVVV2,		-- TYPE 1
				SourceSet.strXXXCategoryDesc,		-- TYPE 1
				SourceSet.strXXXDesc,				-- TYPE 2
				SourceSet.strUnitOfIssue,				-- TYPE 0
				SourceSet.strUnitOfIssueDesc,			-- TYPE 1
				SourceSet.curUnitPrice,					-- TYPE 2

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',

							 SourceSet.strVVV1
							 + '|' + SourceSet.strVVV2
							 + '|' + ISNULL(SourceSet.strXXXCategoryDesc, '')
							 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')

						) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strXXXDesc
							+ '|' + CAST(SourceSet.curUnitPrice AS nvarchar(10))

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			(BogusSales_Live.Corporate.lvwXXXsWideV01 AS SourceSet

			LEFT JOIN Corporate.dimXXX AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.strXXXCode = DestinyTable.strXXXCode))

		WHERE
			(DestinyTable.strXXXCode IS NULL)

		ORDER BY 
			SourceSet.strXXXCode;

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added new dimension records: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END


	END -- Step Two


	---------------------------------------------------------------
	-- Synchronization Step Three -- Update Existing Type 2 SCDs --
	---------------------------------------------------------------
	IF(1=1)
	BEGIN

		--------------------------------------------------
		-- Create a new (Current) version of the record --
		--------------------------------------------------

		INSERT INTO Corporate.dimXXX
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				strXXXCode, 
				strXXXName, 
				strVVV1, 
				strVVV2, 
				strXXXCategoryDesc, 
				strXXXDesc, 
				strUnitOfIssue, 
				strUnitOfIssueDesc,  
				curUnitPrice, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				100, --Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.strXXXCode,				-- TYPE 0
				SourceSet.strXXXName,				-- TYPE 0
				SourceSet.strVVV1,		-- TYPE 1
				SourceSet.strVVV2,		-- TYPE 1
				SourceSet.strXXXCategoryDesc,		-- TYPE 1
				SourceSet.strXXXDesc,				-- TYPE 2
				SourceSet.strUnitOfIssue,				-- TYPE 0
				SourceSet.strUnitOfIssueDesc,			-- TYPE 1
				SourceSet.curUnitPrice,					-- TYPE 2

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				HASHBYTES('SHA1',

							 SourceSet.strVVV1
							 + '|' + SourceSet.strVVV2
							 + '|' + ISNULL(SourceSet.strXXXCategoryDesc, '')
							 + '|' + ISNULL(SourceSet.strUnitOfIssueDesc, '')

						) AS binHashSCDType1,

				HASHBYTES('SHA1',
	
							SourceSet.strXXXDesc
							+ '|' + CAST(SourceSet.curUnitPrice AS nvarchar(10))

						) AS binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM	(

				-------------------------------------------------------
				-- Expire the (now historical) version of the record --
				-------------------------------------------------------

					UPDATE Corporate.dimXXX
					SET
						dteThruDate				= CURRENT_TIMESTAMP,
						blnCurrentFlag			= 0,
						dteUpdatedDate			= CURRENT_TIMESTAMP

						--binHashSCDType2			= HASHBYTES('SHA1',
						--										SourceSet.strXXXDesc
						--										+ '|' + CAST(SourceSet.curUnitPrice AS nvarchar(10))
						--									) --

					OUTPUT SourceSet.*

					FROM 
						(BogusSales_Live.Corporate.lvwXXXsWideV01 AS SourceSet

						INNER JOIN Corporate.dimXXX AS DestinyTable
						ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
						AND (SourceSet.strXXXCode = DestinyTable.strXXXCode)
						AND (1 = DestinyTable.blnCurrentFlag)
						AND (
								HASHBYTES('SHA1',
	
										SourceSet.strXXXDesc
										+ '|' + CAST(SourceSet.curUnitPrice AS nvarchar(10))

									) <> DestinyTable.binHashSCDType2
							) --

						) -- Who's your momma?

				) AS SourceSet

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Expired/Added Type 2 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END -- Step Three
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncXXXDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncXXXDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncXXXDimension', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncXXXDimension', -1, -1);
	
GO
