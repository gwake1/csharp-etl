
-- Delete any pre-existing occurrence of this procedure

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.prcSyncPartyDimension')) 
			AND ([type] IN (N'P', N'PC'))
	)
	DROP PROCEDURE Corporate.prcSyncPartyDimension;
GO

-- Procedure:	prcSyncPartyDimension

-- Purpose:	This procedure synchronizes the Party Dimension table with it's source/sources.

-- ReturnStatus Codes:

		-- 0	Successful completion
		-- 1	Errors

-- Execute Mode
		-- 1	TYPE 1 Upates
		-- 2	Add New Records
		-- 4	TYPE 2 Expire/Add

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.09	Jeffrey Schenk	Original creation of this procedure

CREATE PROCEDURE Corporate.prcSyncPartyDimension
(
	@intExecuteMode			tinyint	= 7,		-- Do everything by default
	@intSuccessCode			int		= 64014,
	@intFailureCode			int		= 64015,
	@blnDebugMode			bit		= 0
)
WITH EXECUTE AS CALLER, ENCRYPTION

AS
	---------------------------------
	-- Local variable declarations --
	---------------------------------

	DECLARE @strMessage			nvarchar(440)	= '';
	DECLARE @intRowCount		int				= 0;
	DECLARE @intIdentityValue	int				= 0;
	DECLARE @intErrorBuffer		int				= 0;
	DECLARE @intReturnStatus	int				= 0;
	DECLARE @intReturnValue		int				= 0;
	DECLARE @intErrorCode		int				= 0;
	DECLARE @intDataSourceKey	int				= Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1);

	------------------------------
	-- Initialization and Setup --
	------------------------------

	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Synchronization Step One -- Update Existing Type 1 SCDs --
	-------------------------------------------------------------

	IF((@intExecuteMode & 1) = 1)  -- 0000 0001 then update 
	BEGIN

		UPDATE Corporate.dimParty
		SET
			
			strPronunciation		= SourceSet.strPronunciation,		-- TYPE 1
			strReferralSource		= SourceSet.strReferralSource,		-- TYPE 1
			dteUpdatedDate			= CURRENT_TIMESTAMP,
			binHashSCDType1			= SourceSet.binHashSCDType1

		FROM 
			(Maintenance.lvwPartyDimensionV01 AS SourceSet

			INNER JOIN Corporate.dimParty AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber)
			AND (SourceSet.binHashSCDType1 <> DestinyTable.binHashSCDType1)); 

			------------------
			-- Did it work? --
			------------------

			SELECT
				@intErrorBuffer = @@ERROR,
				@intRowCount = @@ROWCOUNT;

			IF (@intErrorBuffer = 0)
			BEGIN

				----------------
				-- It worked! --
				----------------

				SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
					+ 'Updated Type 1 SCDs: ' 
					+ CAST(@intRowCount AS nvarchar(10));
			END

	END

	-------------------------------------------------------------------------------
	-- Synchronization Step Two -- Insert New Records From Source System Table/s --
	-------------------------------------------------------------------------------

	IF((@intExecuteMode & 2) = 2)  -- 0000 0010 then update
	BEGIN

		INSERT INTO Corporate.dimParty
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				intPartyNumber, 
				strPartyType, 
				strPartyName, 
				strPartyStatus, 
				strCreditStatus, 
				strPronunciation, 
				strReferralSource, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				@intDataSourceKey AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intPartyNumber,		-- Can Not Change!
				SourceSet.strPartyType,			-- TYPE 2
				SourceSet.strPartyName,			-- TYPE 2
				SourceSet.strPartyStatus,		-- TYPE 2
				SourceSet.strCreditStatus,		-- TYPE 2
				SourceSet.strPronunciation,		-- TYPE 1
				SourceSet.strReferralSource,	-- TYPE 1

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				SourceSet.binHashSCDType1,
				SourceSet.binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 
			(Maintenance.lvwPartyDimensionV01 AS SourceSet

			LEFT JOIN Corporate.dimParty AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber))

		WHERE
			(DestinyTable.intPartyNumber IS NULL)

		ORDER BY 
			SourceSet.intPartyNumber;

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added new dimension records: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END


	END -- Step Two


	---------------------------------------------------------------
	-- Synchronization Step Three -- Update Existing Type 2 SCDs --
	---------------------------------------------------------------
	IF((@intExecuteMode & 4) = 4)  -- 0000 0100 then update
	BEGIN

		-------------------------------------------------------
		-- Expire the (now historical) version of the record --
		-------------------------------------------------------

		DECLARE @ExpiredType2SCDs TABLE 
		(
			intPartyNumber partynumber NOT NULL
		);

		UPDATE Corporate.dimParty
		SET
			dteThruDate				= CURRENT_TIMESTAMP,
			blnCurrentFlag			= 0,
			dteUpdatedDate			= CURRENT_TIMESTAMP

		OUTPUT SourceSet.intPartyNumber INTO @ExpiredType2SCDs

		FROM 
			(Maintenance.lvwPartyDimensionV01 AS SourceSet

			INNER JOIN Corporate.dimParty AS DestinyTable
			ON ('BogusSales_Live' = DestinyTable.strDataSourceName)
			AND (SourceSet.intPartyNumber = DestinyTable.intPartyNumber)
			AND (1 = DestinyTable.blnCurrentFlag)
			AND (SourceSet.binHashSCDType2 <> DestinyTable.binHashSCDType2));

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Expired Type 2 SCDs: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END

		--------------------------------------------------
		-- Create a new (Current) version of the record --
		--------------------------------------------------

		INSERT INTO Corporate.dimParty
		(
				intDataSource_KEY, 
				intDataSourceNumber, 
				strDataSourceName, 
				intPartyNumber, 
				strPartyType, 
				strPartyName, 
				strPartyStatus, 
				strCreditStatus, 
				strPronunciation, 
				strReferralSource, 
				dteFromDate, 
				dteThruDate, 
				blnCurrentFlag, 
				binHashSCDType1, 
				binHashSCDType2, 
				dteUpdatedDate
		)
		SELECT
				@intDataSourceKey AS intDataSource_KEY, 
				1 AS intDataSourceNumber,
				'BogusSales_Live' AS strDataSourceName,

				SourceSet.intPartyNumber,		-- Can Not Change!
				SourceSet.strPartyType,			-- TYPE 2
				SourceSet.strPartyName,			-- TYPE 2
				SourceSet.strPartyStatus,		-- TYPE 2
				SourceSet.strCreditStatus,		-- TYPE 2
				SourceSet.strPronunciation,		-- TYPE 1
				SourceSet.strReferralSource,	-- TYPE 1

				CURRENT_TIMESTAMP AS dteFromDate, 
				NULL AS dteThruDate, 
				1 AS blnCurrentFlag, 

				SourceSet.binHashSCDType1,
				SourceSet.binHashSCDType2,

				CURRENT_TIMESTAMP AS dteUpdatedDate 

		FROM 	
			Maintenance.lvwPartyDimensionV01 AS SourceSet
		WHERE
			(SourceSet.intPartyNumber IN (SELECT intPartyNumber FROM @ExpiredType2SCDs));

		------------------
		-- Did it work? --
		------------------

		SELECT
			@intErrorBuffer = @@ERROR,
			@intRowCount = @@ROWCOUNT;

		IF (@intErrorBuffer = 0)
		BEGIN

			----------------
			-- It worked! --
			----------------

			SELECT @strMessage = @strMessage + CHAR(13) + CHAR(10) + CHAR(9)
				+ 'Added Type 2 SCDs: ' 
				+ CAST(@intRowCount AS nvarchar(10));
		END

	END -- Step Three
	
	-------------------------------------------------------------------  
	-- Determine whether to pass a success or failure raiserror code --
	-------------------------------------------------------------------  

	SET @intErrorCode = IIF(@intReturnValue = 0, @intSuccessCode, @intFailureCode);

	--------------------------------------------------
	-- Return success or failure data to the caller --
	--------------------------------------------------

	IF (@blnDebugMode = 1)
	BEGIN
		-------------------------------------------------------------------------------------
		-- Pass knowledge of success or failure to the Sql Server error log / NT event log --
		-------------------------------------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage) WITH LOG;
		ELSE
			RAISERROR('prcSyncPartyDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage) WITH LOG;

	END		-------------------------------------------------------
	ELSE	-- Don't bother passing the results to the error log --
	BEGIN	-------------------------------------------------------

		IF (@intErrorCode IS NOT NULL)
			RAISERROR(@intErrorCode, -1, -1, @intReturnValue, @strMessage);
		ELSE
			RAISERROR('prcSyncPartyDimension -- ReturnCode(%d): %s', -1, -1, @intReturnValue, @strMessage);
	END

	RETURN(@intReturnValue);
GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Procedure Corporate.prcSyncPartyDimension', -1, -1);
	ELSE
		RAISERROR('Created Procedure Corporate.prcSyncPartyDimension', -1, -1);
	
GO
