
-- DataSources Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this index script


	ALTER TABLE Corporate.tblDataSources ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT PKC_Corp_DataSources_DataSource_Key PRIMARY KEY CLUSTERED (intDataSource_Key)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 100, DATA_COMPRESSION = NONE) ON [DEFAULT],

		CONSTRAINT UQX_Corp_DataSources_DataSourceNumber UNIQUE NONCLUSTERED (intDataSourceNumber)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 100, DATA_COMPRESSION = NONE) ON [DEFAULT],

		CONSTRAINT UQX_Corp_DataSources_DataSourceName UNIQUE NONCLUSTERED (strDataSourceName)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 100, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create indexes for dbo.tblDataSources', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created indexes for dbo.tblDataSources', -1, -1);
	END
GO
