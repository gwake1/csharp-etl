
-- BusinessUnit Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this index script


	ALTER TABLE Corporate.dimBusinessUnit ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT PKC_Corp_BusinessUnit_BusinessUnit_KEY PRIMARY KEY CLUSTERED (intBusinessUnit_KEY)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT],
			
		CONSTRAINT UQX_Corp_BusinessUnit_BusinessUnit_GUID UNIQUE NONCLUSTERED (uidBusinessUnit_GUID)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	--CREATE CLUSTERED INDEX IDX_Corp_BusinessUnit_YYY ON Corporate.dimBusinessUnit(intYYY)
	--	WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create indexes for Corporate.dimBusinessUnit', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created indexes for Corporate.dimBusinessUnit', -1, -1);
	END
GO
