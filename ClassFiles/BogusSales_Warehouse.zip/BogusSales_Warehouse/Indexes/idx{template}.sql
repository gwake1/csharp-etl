
-- XXX Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this index script


	ALTER TABLE SSS.PPPXXX ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT PKC_Corp_XXX_XXX_KEY PRIMARY KEY CLUSTERED (intXXX_KEY)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT],
			
		CONSTRAINT UQX_Corp_XXX_XXX_GUID UNIQUE NONCLUSTERED (uidXXX_GUID)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	--CREATE CLUSTERED INDEX IDX_Corp_XXX_YYY ON SSS.PPPXXX(intYYY)
	--	WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create indexes for SSS.PPPXXX', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created indexes for SSS.PPPXXX', -1, -1);
	END
GO
