
-- Party Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this index script


	ALTER TABLE Corporate.dimParty ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT PKC_Corp_Party_Party_KEY PRIMARY KEY CLUSTERED (intParty_KEY)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT],
			
		CONSTRAINT UQX_Corp_Party_Party_GUID UNIQUE NONCLUSTERED (uidParty_GUID)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	--CREATE CLUSTERED INDEX IDX_Corp_Party_YYY ON Corporate.dimParty(intYYY)
	--	WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create indexes for Corporate.dimParty', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created indexes for Corporate.dimParty', -1, -1);
	END
GO
