
-- Shipper Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this index script


	ALTER TABLE Corporate.dimShipper ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT PKC_Corp_Shipper_Shipper_KEY PRIMARY KEY CLUSTERED (intShipper_KEY)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT],
			
		CONSTRAINT UQX_Corp_Shipper_Shipper_GUID UNIQUE NONCLUSTERED (uidShipper_GUID)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	--CREATE CLUSTERED INDEX IDX_Corp_Shipper_YYY ON Corporate.dimShipper(intYYY)
	--	WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create indexes for Corporate.dimShipper', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created indexes for Corporate.dimShipper', -1, -1);
	END
GO
