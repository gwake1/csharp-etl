
-- Sales Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this index script


	ALTER TABLE Corporate.factSales ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT UQC_Corp_FactSales_KeyFields UNIQUE CLUSTERED 
		(	
			intBusinessUnit_KEY,
			intDate_KEY,
			intProduct_KEY,
			intShipper_KEY,
			intStore_KEY,
			intCustomerParty_KEY,
			intSalesRepParty_KEY,
			intOrderNumber
		)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT],

		CONSTRAINT PKX_Corp_FactSales_FactSales_KEY PRIMARY KEY NONCLUSTERED (intFactSales_KEY)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT],
			
		CONSTRAINT UQX_Corp_FactSales_FactSales_GUID UNIQUE NONCLUSTERED (uidFactSales_GUID)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];


	CREATE NONCLUSTERED INDEX IDX_Corp_FactSales_BusinessUnit_KEY ON Corporate.factSales(intBusinessUnit_KEY)
		WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	CREATE NONCLUSTERED INDEX IDX_Corp_FactSales_Date_KEY ON Corporate.factSales(intDate_KEY)
		WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	CREATE NONCLUSTERED INDEX IDX_Corp_FactSales_Product_KEY ON Corporate.factSales(intProduct_KEY)
		WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	CREATE NONCLUSTERED INDEX IDX_Corp_FactSales_Shipper_KEY ON Corporate.factSales(intShipper_KEY)
		WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	CREATE NONCLUSTERED INDEX IDX_Corp_FactSales_Store_KEY ON Corporate.factSales(intStore_KEY)
		WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	CREATE NONCLUSTERED INDEX IDX_Corp_FactSales_CustomerParty_KEY ON Corporate.factSales(intCustomerParty_KEY)
		WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	CREATE NONCLUSTERED INDEX IDX_Corp_FactSales_SalesRepParty_KEY ON Corporate.factSales(intSalesRepParty_KEY)
		WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create indexes for Corporate.factSales', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created indexes for Corporate.factSales', -1, -1);
	END
GO
