
-- Date Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2008.01.29	Jeffrey Schenk	Original creation of this index script

	ALTER TABLE Corporate.dimDate ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT PKC_Corp_Date_Date_KEY PRIMARY KEY CLUSTERED (intDate_KEY)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 99, DATA_COMPRESSION = NONE) ON [DEFAULT],

		CONSTRAINT UQX_Corp_Date_CalendarDate UNIQUE NONCLUSTERED (dteCalendarDate)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 99, DATA_COMPRESSION = NONE) ON [DEFAULT],

		CONSTRAINT UQX_Corp_Date_Date_GUID UNIQUE NONCLUSTERED (uidDate_GUID)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 99, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could not create indexes for Corporate.dimDate', -1, -1)
	ELSE
		RAISERROR('Created indexes for Corporate.dimDate', -1, -1)
GO
