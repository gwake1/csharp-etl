
-- Supplier Indexes

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this index script


	ALTER TABLE Corporate.dimSupplier ADD --Create Primary and Unique Indexes as Constraints

		CONSTRAINT PKC_Corp_Supplier_Supplier_KEY PRIMARY KEY CLUSTERED (intSupplier_KEY)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT],
			
		CONSTRAINT UQX_Corp_Supplier_Supplier_GUID UNIQUE NONCLUSTERED (uidSupplier_GUID)
			WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

	--CREATE CLUSTERED INDEX IDX_Corp_Supplier_YYY ON Corporate.dimSupplier(intYYY)
	--	WITH (PAD_INDEX = OFF, FILLFACTOR = 95, DATA_COMPRESSION = NONE) ON [DEFAULT];

GO	
	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could not create indexes for Corporate.dimSupplier', -1, -1);
	ELSE
		RAISERROR('Created indexes for Corporate.dimSupplier', -1, -1);
GO
