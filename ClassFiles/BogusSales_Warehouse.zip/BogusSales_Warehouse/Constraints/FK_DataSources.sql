
-- DataSources Constraints

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2008.01.29	Jeffrey Schenk	Original creation of this foreign key constraint

	SET NOCOUNT ON

-- Constraints Follow

-- No foreign key constraints currently defined.

/*
	ALTER TABLE Corporate.tblDataSources
		ADD CONSTRAINT FK_Corp_DataSources_YYY 
			FOREIGN KEY (YYY_ID) 
				REFERENCES Corporate.tblYYY (YYY_ID);
*/

GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Creating foreign key constraints for Corporate.tblDataSources', -1, -1);
	END

	ELSE --Things went well... or no foreign key constraints to set
	BEGIN
		--RAISERROR('Created foreign key constraints for Corporate.tblDataSources', -1, -1);
		RAISERROR('No foreign key constraints currently defined for Corporate.tblDataSources', -1, -1);
	END
GO
