
-- Sales Constraints

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this foreign key constraint

	SET NOCOUNT ON

-- Constraints Follow

	ALTER TABLE Corporate.factSales
		ADD CONSTRAINT FK_Corp_FactSales_BusinessUnit_KEY
			FOREIGN KEY (intBusinessUnit_KEY) 
				REFERENCES Corporate.dimBusinessUnit (intBusinessUnit_KEY);

	ALTER TABLE Corporate.factSales
		ADD CONSTRAINT FK_Corp_FactSales_Date_KEY
			FOREIGN KEY (intDate_KEY) 
				REFERENCES Corporate.dimDate (intDate_KEY);

	ALTER TABLE Corporate.factSales
		ADD CONSTRAINT FK_Corp_FactSales_Product_KEY
			FOREIGN KEY (intProduct_KEY) 
				REFERENCES Corporate.dimProduct (intProduct_KEY);

	ALTER TABLE Corporate.factSales
		ADD CONSTRAINT FK_Corp_FactSales_Shipper_KEY
			FOREIGN KEY (intShipper_KEY) 
				REFERENCES Corporate.dimShipper (intShipper_KEY);

	ALTER TABLE Corporate.factSales
		ADD CONSTRAINT FK_Corp_FactSales_Store_KEY
			FOREIGN KEY (intStore_KEY) 
				REFERENCES Corporate.dimStore (intStore_KEY);

	ALTER TABLE Corporate.factSales
		ADD CONSTRAINT FK_Corp_FactSales_CustomerParty_KEY
			FOREIGN KEY (intCustomerParty_KEY) 
				REFERENCES Corporate.dimParty (intParty_KEY);

	ALTER TABLE Corporate.factSales
		ADD CONSTRAINT FK_Corp_FactSales_SalesRepParty_KEY
			FOREIGN KEY (intSalesRepParty_KEY) 
				REFERENCES Corporate.dimParty (intParty_KEY);

GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Creating foreign key constraints for Corporate.factSales', -1, -1);
	END
	ELSE --Things went well... or no foreign key constraints to set
	BEGIN
		RAISERROR('Created foreign key constraints for Corporate.factSales', -1, -1)
	END
GO
