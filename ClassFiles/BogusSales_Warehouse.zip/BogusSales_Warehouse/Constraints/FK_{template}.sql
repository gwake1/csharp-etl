
-- XXX Constraints

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this foreign key constraint

	SET NOCOUNT ON

-- Constraints Follow

-- No foreign key constraints currently defined.

/*
	ALTER TABLE SSS.PPPXXX
		ADD CONSTRAINT FK_Corp_XXX_FFF_KEY
			FOREIGN KEY (intFFF_KEY) 
				REFERENCES SSS.RRRFFF (intFFF_KEY);

	ALTER TABLE SSS.PPPXXX
		ADD CONSTRAINT FK_Corp_XXX_DataSource_Key 
			FOREIGN KEY (intDataSource_Key) 
				REFERENCES Corporate.tblDataSources (intDataSource_Key);
*/

GO

--Error Handling Code Follows

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Creating foreign key constraints for SSS.PPPXXX', -1, -1);
	END
	ELSE --Things went well... or no foreign key constraints to set
	BEGIN
		--RAISERROR('Created foreign key constraints for SSS.PPPXXX', -1, -1)
		RAISERROR('No foreign key constraints currently defined for SSS.PPPXXX', -1, -1);
	END
GO
