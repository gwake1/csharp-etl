
-- Delete any pre-existing occurrence of this function

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.fnsConvert_DataSourceNumber_DataSourceKey')) 
			AND ([type] IN (N'FN', N'IF', N'TF', N'FS', N'FT'))
	)
	DROP FUNCTION Corporate.fnsConvert_DataSourceNumber_DataSourceKey
GO

-- Function:	fnsConvert_DataSourceNumber_DataSourceKey

-- Purpose:	This scalar function returns intDataSource_ID, given intDataSourceNumber

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2007.08.19	Jeffrey Schenk	Original creation of this scalar function

CREATE FUNCTION Corporate.fnsConvert_DataSourceNumber_DataSourceKey
(
	@intDataSourceNumber datasourcenumber = NULL
)

RETURNS datasource_key 

WITH EXECUTE AS CALLER, ENCRYPTION

AS

BEGIN -- fnsConvert_DataSourceNumber_DataSourceKey

	RETURN (SELECT intDataSource_KEY FROM Corporate.tblDataSources WHERE (@intDataSourceNumber = intDataSourceNumber));

END -- fnsConvert_DataSourceNumber_DataSourceKey

GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could Not Create Scalar Function Corporate.fnsConvert_DataSourceNumber_DataSourceKey', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created Scalar Function Corporate.fnsConvert_DataSourceNumber_DataSourceKey', -1, -1);
	END
GO



