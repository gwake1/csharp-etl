
-- Delete any pre-existing occurrence of this function

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'dbo.fntXXX')) 
			AND ([type] IN (N'FN', N'IF', N'TF', N'FS', N'FT'))
	)
	DROP FUNCTION dbo.fntXXX
GO

-- Function:	fntXXX

-- Purpose:	This Function does wonderful stuff.
-- Sample call:	

-- Note:	Multi-valued table functions can't Use user-defined types!

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original Creation of this MV Table Function


CREATE FUNCTION dbo.fntXXX
(
		@intXXXValue	int				= NULL,
		@strXXXName		nvarchar(20)	= NULL
)

RETURNS @PPPXXX TABLE -- Build your custom table below...

	(
	intXXX_ID	int		NOT NULL IDENTITY(1,1),
	strXXXName	nvarchar(40)	NULL
	strXXXNote	nvarchar(80)	NULL
	)

AS

BEGIN -- fntXXX
    

	INSERT INTO @PPPXXX 
	(
		strXXXname, 
		strXXXNote
	)
	SELECT 
		'SomeName',
		'SomeNote'

    RETURN

END -- fntXXX


GO

	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Multi-Valued Table Function dbo.fntXXX', -1, -1)
	ELSE
		RAISERROR('Created Multi-Valued Table Function dbo.fntXXX', -1, -1)
	
GO



