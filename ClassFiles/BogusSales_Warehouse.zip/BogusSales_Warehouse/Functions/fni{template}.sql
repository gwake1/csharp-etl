
-- Delete any pre-existing occurrence of this function

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'dbo.fniXXX')) 
			AND ([type] IN (N'FN', N'IF', N'TF', N'FS', N'FT'))
	)
	DROP FUNCTION dbo.fniXXX
GO

-- Function:	fniXXX

-- Purpose:	This Function does wonderful stuff.
-- Sample call:	

-- Note:

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original Creation of this Inline Table Function


CREATE FUNCTION dbo.fniXXX
(
		@intXXXValue	int		= NULL,
		@strXXXName	nvarchar(20)	= NULL
)

RETURNS TABLE -- That you make by way of a  select statement in return clause

AS
    
RETURN (SELECT * FROM dbo.tblParties)



GO

	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could Not Create Inline Table Function dbo.fniXXX', -1, -1);
	END
	ELSE
	BEGIN
		RAISERROR('Created Inline Table Function dbo.fniXXX', -1, -1);
	END
	
GO



