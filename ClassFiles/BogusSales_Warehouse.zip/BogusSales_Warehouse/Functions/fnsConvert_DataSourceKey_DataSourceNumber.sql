
-- Delete any pre-existing occurrence of this function

IF EXISTS(	SELECT * FROM sys.objects  
			WHERE ([object_id] = OBJECT_ID(N'Corporate.fnsConvert_DataSourceKey_DataSourceNumber')) 
			AND ([type] IN (N'FN', N'IF', N'TF', N'FS', N'FT'))
	)
	DROP FUNCTION Corporate.fnsConvert_DataSourceKey_DataSourceNumber
GO

-- Function:	fnsConvert_DataSourceKey_DataSourceNumber

-- Purpose:	This scalar function returns intDataSourceNumber, given intDataSource_ID

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2007.08.19	Jeffrey Schenk	Original creation of this scalar function

CREATE FUNCTION Corporate.fnsConvert_DataSourceKey_DataSourceNumber
(
	@intDataSource_Key integer = NULL --datasource_key = NULL
)

RETURNS integer --datasourcenumber 

WITH EXECUTE AS CALLER, ENCRYPTION, SCHEMABINDING

AS

BEGIN -- fnsConvert_DataSourceKey_DataSourceNumber

	RETURN (SELECT intDataSourceNumber FROM Corporate.tblDataSources WHERE (@intDataSource_Key = intDataSource_Key))

END -- fnsConvert_DataSourceKey_DataSourceNumber

GO
	IF(@@ERROR <> 0)
		RAISERROR('ERROR: Could Not Create Scalar Function Corporate.fnsConvert_DataSourceKey_DataSourceNumber', -1, -1)
	ELSE
		RAISERROR('Created Scalar Function Corporate.fnsConvert_DataSourceKey_DataSourceNumber', -1, -1)
	
GO



