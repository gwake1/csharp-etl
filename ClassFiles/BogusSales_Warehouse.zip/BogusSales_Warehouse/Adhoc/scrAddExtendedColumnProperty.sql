
-- sp_addextendedproperty (Transact-SQL)
-- http://msdn.microsoft.com/en-us/library/ms180047.aspx

-- Using Extended Properties on Database Objects
-- http://msdn.microsoft.com/en-us/library/ms190243.aspx

-- Viewing Extended Properties
-- http://msdn.microsoft.com/en-us/library/ms186989.aspx

-- fn_listextendedproperty (Transact-SQL)
-- http://msdn.microsoft.com/en-us/library/ms179853.aspx

USE DataSchenk_Warehouse;
GO
EXEC sp_addextendedproperty 
	@name = N'SCDType', 
	@value = '2',
	@level0type = N'Schema', 
	@level0name = N'Corporate',
	@level1type = N'Table',  
	@level1name = N'DimParty',
	@level2type = N'Column', 
	@level2name = N'strPartyName';
	
	
EXEC sp_addextendedproperty 
	@name = N'SCDType', 
	@value = '2',
	@level0type = N'Schema', 
	@level0name = N'Corporate',
	@level1type = N'Table',  
	@level1name = N'DimParty',
	@level2type = N'Column', 
	@level2name = N'intPartyNumber';

-- Display all extended properties in the database
SELECT 
	class, 
	class_desc, 
	major_id, 
	minor_id, 
	name, 
	value
FROM sys.extended_properties;

-- Display all extended properties for columns on the dimParty table
-- Just shows column-level properties (not table-level properties)

SELECT 
	objtype, 
	objname, 
	name, 
	value
FROM fn_listextendedproperty (NULL, 'schema', 'Corporate', 'table', 'dimParty', 'column', default);
