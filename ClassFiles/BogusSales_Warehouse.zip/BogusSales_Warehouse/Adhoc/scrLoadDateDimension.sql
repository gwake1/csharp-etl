
--SELECT CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimDate') ORDER BY column_id;

INSERT INTO Corporate.dimDate
(
	intDate_KEY, 
	intDataSource_KEY, 
	intDataSourceNumber, 
	strDataSourceName, 
	dteCalendarDate, 
	intYearNumber, 
	intSeasonNumber, 
	strSeasonName, 
	intQuarterNumber, 
	strQuarterYearName, 
	strQuarterName, 
	intMonthNumber, 
	strMonthYearName, 
	strMonthName, 
	strMonthDayName, 
	intWeekNumberOfYear, 
	intDayNumberOfBogusSales, 
	intDayNumberOfYear, 
	intDayNumberOfMonth, 
	intDayNumberOfWeek, 
	strDayNameOfWeek,
	intOrdinalDay, 
	blnWorkDay, 
	strCalendarDayName,
	dteFromDate, 
	blnCurrentFlag,
	binHashSCDType1, 
	binHashSCDType2, 
	dteUpdatedDate
)
SELECT
	CAST(CONVERT(varchar, CDays.dteCalendarDate, 112) AS int) AS intDate_KEY,
	Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY,
	1 AS intDataSourceNumber,
	'BogusSales_Live' AS strDataSourceName,
	CDays.dteCalendarDate AS dteCalendarDate, 

	DATEPART(year, CDays.dteCalendarDate) AS intYearNumber,
	CDays.intSeason AS intSeasonNumber, 

	CASE 
		WHEN (CDays.intSeason = 1) THEN 'Spring'
		WHEN (CDays.intSeason = 2) THEN 'Summer'
		WHEN (CDays.intSeason = 3) THEN 'Fall'
		ELSE 'Winter'
	END 
		AS strSeasonName,
						 
	DATEPART(quarter, CDays.dteCalendarDate) AS intQuarterNumber,
	
	CASE 
		WHEN (CDays.intQuarter = 1) THEN 'Q1'
		WHEN (CDays.intQuarter = 2) THEN 'Q2'
		WHEN (CDays.intQuarter = 3) THEN 'Q3'
		ELSE 'Q4'
	END  
		+ ' ' + CAST(DATEPART(year, CDays.dteCalendarDate) AS nvarchar) AS strQuarterYearName,

	CASE 
		WHEN (CDays.intQuarter = 1) THEN 'Q1'
		WHEN (CDays.intQuarter = 2) THEN 'Q2'
		WHEN (CDays.intQuarter = 3) THEN 'Q3'
		ELSE 'Q4'
	END 
		AS strQuarterName,

	CDays.intMonth AS intMonthNumber, 
	LEFT(CONVERT(nvarchar, CDays.dteCalendarDate, 107), 4) 
		+ CAST(DATEPART(year, CDays.dteCalendarDate) AS nvarchar) AS strMonthYearName,

	DATENAME(month, CDays.dteCalendarDate) AS strMonthName,
	LEFT(CONVERT(nvarchar, CDays.dteCalendarDate, 107), 6) AS strMonthDayName,
	DATEPART(week, CDays.dteCalendarDate) AS intWeekNumberOfYear,
	CDays.intDayNumber AS intDayNumberOfBogusSales,
	DATEPART(dayofyear, CDays.dteCalendarDate) AS intDayNumberOfYear,
	DATEPART(day, CDays.dteCalendarDate) AS intDayNumberOfMonth,
	DATEPART(weekday, CDays.dteCalendarDate) AS intDayNumberOfWeek,
	DATENAME(weekday, CDays.dteCalendarDate) AS strDayNameOfWeek,
	CDays.intOrdinalDay, 
	CDays.blnWorkDay, 
	CDays.strCalendarDayName,
	CURRENT_TIMESTAMP AS dteFromDate, 
	1 AS blnCurrentFlag,
	HASHBYTES('SHA1', ISNULL(CDays.strCalendarDayName,'')) AS binHashSCDType1,
	HASHBYTES('SHA1',
	
		CAST(ISNULL(intYear, 0) AS varchar(10))
		+ '~' + CAST(ISNULL(CDays.intOrdinalDay, 0) AS varchar(10))
		+ '~' + CAST(ISNULL(CDays.intMonth, 0) AS varchar(10))
		+ '~' + CAST(ISNULL(CDays.intQuarter, 0) AS varchar(10))
		+ '~' +CAST(ISNULL(CDays.intDay, 0) AS varchar(10))

	 ) AS binHashSCDType2,
	CURRENT_TIMESTAMP dteUpdatedDate 

FROM 
	(BogusSales_Live.Corporate.tblCalendarDays AS CDays

	LEFT JOIN Corporate.dimDate AS DDays
	ON ('BogusSales_Live' = DDays.strDataSourceName)
	AND (CDays.dteCalendarDate = DDays.dteCalendarDate))

WHERE
	(DDays.dteCalendarDate IS NULL)

ORDER BY 
	dteCalendarDate;

