
INSERT INTO Corporate.dimProduct
(
		--intProduct_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		strProductCode, 
		strProductName, 
		strProductCategoryCode, 
		strProductCategoryName, 
		strProductCategoryDesc, 
		strProductDesc, 
		strUnitOfIssue, 
		strUnitOfIssueDesc,  
		curUnitPrice, 
		dteFromDate, 
		dteThruDate, 
		blnCurrentFlag, 
		binHashSCDType1, 
		binHashSCDType2, 
		dteUpdatedDate
)
SELECT
		--intProduct_KEY, 
		Corporate.fnsConvert_DataSourceNumber_DataSourceKey(1) AS intDataSource_KEY, 
		1 AS intDataSourceNumber,
		'BogusSales_Live' AS strDataSourceName,

		ProdSource.strProductCode,				-- TYPE 0
		ProdSource.strProductName,				-- TYPE 0
		ProdSource.strProductCategoryCode,		-- TYPE 1
		ProdSource.strProductCategoryName,		-- TYPE 1
		ProdSource.strProductCategoryDesc,		-- TYPE 1
		ProdSource.strProductDesc,				-- TYPE 2
		ProdSource.strUnitOfIssue,				-- TYPE 0
		ProdSource.strUnitOfIssueDesc,			-- TYPE 1
		ProdSource.curUnitPrice,				-- TYPE 2

		CURRENT_TIMESTAMP AS dteFromDate, 
		NULL AS dteThruDate, 
		1 AS blnCurrentFlag, 

		HASHBYTES('SHA1',

					 ProdSource.strProductCategoryCode
					 + '|' + ProdSource.strProductCategoryName
					 + '|' + ISNULL(ProdSource.strProductCategoryDesc, '')
					 + '|' + ISNULL(ProdSource.strUnitOfIssueDesc, '')

				) AS binHashSCDType1,

		HASHBYTES('SHA1',
	
					ProdSource.strProductDesc
					+ '|' + CAST(ProdSource.curUnitPrice AS nvarchar(10))

				) AS binHashSCDType2,

		CURRENT_TIMESTAMP AS dteUpdatedDate 

FROM 
	(BogusSales_Live.Corporate.lvwProductsWideV01 AS ProdSource

	LEFT JOIN Corporate.dimProduct AS ProdDim
	ON (ProdSource.strProductCode = ProdDim.strProductCode))

WHERE
	(ProdDim.strProductCode IS NULL)

ORDER BY 
	ProdSource.strProductCode;