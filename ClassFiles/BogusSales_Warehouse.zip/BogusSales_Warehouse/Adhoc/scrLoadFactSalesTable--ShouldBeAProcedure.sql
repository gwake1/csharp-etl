
INSERT INTO Corporate.factSales
(
	intBusinessUnit_KEY,
	intDate_KEY,
	intProduct_KEY,
	intShipper_KEY,
	intStore_KEY,
	intCustomerParty_KEY,
	intSalesRepParty_KEY,
	intOrderNumber,
	intQuantity,
	curUnitPrice,
	dteUpdatedDate
)
SELECT
	-- Surrogate Keys --

	intBusinessUnit_KEY,
	intDate_KEY,
	intProduct_KEY,
	intShipper_KEY,
	intStore_KEY,
	intCustomerParty_KEY,
	intSalesRepParty_KEY,

	-- Degenerate Facts --

	intOrderNumber,

	-- Measures --

	intQuantity,
	curUnitPrice,
	CURRENT_TIMESTAMP dteUpdatedDate

	FROM
		Corporate.lvwSalesFactKeysV01;

