
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.dimShipper')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.dimShipper
GO

-- dimShipper Dimension Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this dimension table

BEGIN TRY

	CREATE TABLE Corporate.dimShipper
	(
	intShipper_KEY			shipper_key			NOT NULL 	IDENTITY(1,1),

	-- Source System Meta Data --

	intDataSource_KEY		datasource_key		NOT NULL,	-- for system synchronization use (not end user presented)
	intDataSourceNumber		datasourcenumber	NOT NULL,	-- for end user presentation
	strDataSourceName		datasourcename		NOT NULL,	-- denormalized display attribute (doing what dim tables do)

	-- Unique Dimension Attributes --
	
	intPartyNumber			partynumber			NOT NULL,
	strOrganizationName		organizationname	NOT NULL,
	strOrgSubTitle			orgsubtitle			NULL,
	strOrgComponentName		organizationname	NULL, 
	intShipperRank			shipperrank			NOT NULL,
	strShipperRankNote		standarddesc		NULL,
	strVoicePhone			phonenumber			NULL,

	-- Standard Dimension Table fare --

	dteFromDate				date				NOT NULL	CONSTRAINT DF_Corp_Shipper_FromDate DEFAULT (CURRENT_TIMESTAMP),
	dteThruDate				date				NULL,
	blnCurrentFlag			bit					NOT NULL	CONSTRAINT DF_Corp_Shipper_CurrentFlag DEFAULT(1),

	-- Audit / Meta Data --

	binHashSCDType1			scdhashtype			NOT NULL	CONSTRAINT DF_Corp_Shipper_HashSCDType1 DEFAULT(0x0),
	binHashSCDType2			scdhashtype			NOT NULL	CONSTRAINT DF_Corp_Shipper_HashSCDType2 DEFAULT(0x0),
	dteUpdatedDate			date				NOT NULL	CONSTRAINT DF_Corp_Shipper_UpdatedDate DEFAULT (CURRENT_TIMESTAMP),
	uidShipper_GUID			uniqueidentifier	NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_Shipper_Date_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion			rowversion			NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.dimShipper';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.dimShipper: ' + ERROR_MESSAGE();

END CATCH

GO


