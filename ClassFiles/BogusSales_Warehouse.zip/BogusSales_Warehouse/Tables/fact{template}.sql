
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'SSS.PPPXXX')) 
			AND ([type] = N'U')
	) DROP TABLE SSS.PPPXXX
GO

-- PPPXXX fact Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this fact table

BEGIN TRY

	CREATE TABLE SSS.PPPXXX
	(
	intXXX_KEY		XXX_key				NOT NULL 	IDENTITY(1,1) NOT FOR REPLICATION,

	-- Attribute Key Columns -- 

	-- Measures --

	-- Audit / Meta Data --

	dtmCreationDate		smalldatetime		NOT NULL	CONSTRAINT DF_Corp_XXX_CreateDate DEFAULT (CURRENT_TIMESTAMP),
	uidXXX_GUID		uniqueidentifier		NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_XXX_XXX_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion		rowversion			NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table SSS.PPPXXX';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table SSS.PPPXXX: ' + ERROR_MESSAGE();

END CATCH

GO


