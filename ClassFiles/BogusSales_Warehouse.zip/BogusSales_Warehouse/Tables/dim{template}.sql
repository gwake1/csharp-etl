
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'SSS.PPPXXX')) 
			AND ([type] = N'U')
	) DROP TABLE SSS.PPPXXX
GO

-- PPPXXX Dimension Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this dimension table

BEGIN TRY

	CREATE TABLE SSS.PPPXXX
	(
	intXXX_KEY		XXX_key				NOT NULL 	IDENTITY(1,1),

	-- Source System Meta Data --

	intDataSource_KEY	datasource_key		NOT NULL,	-- for system synchronization use (not end user presented)
	intDataSourceNumber	datasourcenumber	NOT NULL,	-- for end user presentation
	strDataSourceName	datasourcename		NOT NULL,	-- denormalized display attribute (doing what dim tables do)

	-- Unique Dimension Attributes --

	-- YOUR FIELDS HERE

	-- Standard Dimension Table fare --

	dteFromDate			date				NOT NULL	CONSTRAINT DF_Corp_XXX_FromDate DEFAULT (CURRENT_TIMESTAMP),
	dteThruDate			date				NULL,
	blnCurrentFlag		bit					NOT NULL	CONSTRAINT DF_Corp_XXX_CurrentFlag DEFAULT(1),

	-- Audit / Meta Data --

	binHashSCDType1		scdhashtype			NOT NULL	CONSTRAINT DF_Corp_XXX_HashSCDType1 DEFAULT(0x0),
	binHashSCDType2		scdhashtype			NOT NULL	CONSTRAINT DF_Corp_XXX_HashSCDType2 DEFAULT(0x0),
	dteUpdatedDate		date				NOT NULL	CONSTRAINT DF_Corp_XXX_UpdatedDate DEFAULT (CURRENT_TIMESTAMP),
	uidXXX_GUID		uniqueidentifier		NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_XXX_XXX_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion		rowversion			NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table SSS.PPPXXX';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table SSS.PPPXXX: ' + ERROR_MESSAGE();

END CATCH

GO


