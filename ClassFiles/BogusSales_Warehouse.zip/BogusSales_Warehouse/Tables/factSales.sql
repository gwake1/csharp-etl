
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.factSales')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.factSales
GO

-- factSales fact Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this fact table

BEGIN TRY

	CREATE TABLE Corporate.factSales
	(
	intFactSales_KEY		salesfact_key		NOT NULL 	IDENTITY(1,1),

	-- Surrogate Keys --

	intBusinessUnit_KEY		businessunit_key	NOT NULL,
	intDate_KEY				date_key			NOT NULL,
	intProduct_KEY			product_key			NOT NULL,
	intShipper_KEY			shipper_key			NULL,
	intStore_KEY			store_key			NULL,
	intCustomerParty_KEY	party_key			NOT NULL,
	intSalesRepParty_KEY	party_key			NULL,

	-- Degenerate Facts --

	intOrderNumber			ordernumber			NOT NULL,

	-- Measures --

	intQuantity				smallint			NOT NULL,
	curUnitPrice			money				NOT NULL,
	dteUpdatedDate			date				NOT NULL	CONSTRAINT DF_Corp_FactSales_UpdatedDate DEFAULT (CURRENT_TIMESTAMP),

	-- Audit / Meta Data --

	dtmCreationDate		smalldatetime			NOT NULL	CONSTRAINT DF_Corp_Sales_CreateDate DEFAULT (CURRENT_TIMESTAMP),
	uidFactSales_GUID	uniqueidentifier		NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_FactSales_Sales_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion		rowversion				NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.factSales';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.factSales: ' + ERROR_MESSAGE();

END CATCH

GO


