USE BogusSales_Warehouse
GO

-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.dimSupplier')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.dimSupplier
GO

-- dimSupplier Dimension Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this dimension table

BEGIN TRY

	CREATE TABLE Corporate.dimSupplier
	(
	intSupplier_KEY			supplier_key		NOT NULL 	IDENTITY(1,1) NOT FOR REPLICATION,
	intDataSource_KEY		datasource_key		NOT NULL,
	intDataSourceNumber		datasourcenumber	NOT NULL,
	strDataSourceName		datasourcename		NOT NULL,

	intPartyNumber			partynumber			NOT NULL,
	strOrganizationName		organizationname	NOT NULL,
	strOrgSubTitle			orgsubtitle			NULL,
	strOrgComponentName		organizationname	NULL, 
	intSupplierRank			supplierrank		NOT NULL,	
	strSupplierRankNote		standarddesc		NULL,
	strVoicePhone			phonenumber			NULL,

	-- Standard Dimension Table fare --

	dteFromDate			date					NOT NULL	CONSTRAINT DF_Corp_Supplier_FromDate DEFAULT (CURRENT_TIMESTAMP),
	dteThruDate			date					NULL,
	blnCurrentFlag		bit						NOT NULL	CONSTRAINT DF_Corp_Supplier_CurrentFlag DEFAULT(1),

	-- Audit / Meta Data --

	binHashSCDType1		scdhashtype				NOT NULL	CONSTRAINT DF_Corp_Supplier_HashSCDType1 DEFAULT(0x0),
	binHashSCDType2		scdhashtype				NOT NULL	CONSTRAINT DF_Corp_Supplier_HashSCDType2 DEFAULT(0x0),
	dteUpdatedDate		date					NOT NULL	CONSTRAINT DF_Corp_Supplier_UpdatedDate DEFAULT (CURRENT_TIMESTAMP),
	uidSupplier_GUID	uniqueidentifier		NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_Supplier_Product_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion		rowversion				NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.dimSupplier';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.dimSupplier: ' + ERROR_MESSAGE();

END CATCH

GO


