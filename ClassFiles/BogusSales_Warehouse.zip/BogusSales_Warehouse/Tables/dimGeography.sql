
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.dimGeography')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.dimGeography
GO

-- dimGeography Dimension Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2007.01.22	Jeffrey Schenk	Original creation of this dimension table

BEGIN TRY

	CREATE TABLE Corporate.dimGeography
	(
	intGeography_KEY	geography_key		NOT NULL 	IDENTITY(1,1) NOT FOR REPLICATION,
	strCityOrTown		cityortown			NULL
	strProvinceName		provincename		NULL,
	strProvinceAbbr		provinceabbr		NULL,
	strMarketCity		marketcity			NULL,
	strMarketProvAbbr	provinceabbr		NULL,
	strCountryName		countryname			NULL
	strCountryNumber	countrynumber		NULL
	strPostalCode		postalcode			NULL,

	-- Audit / Meta Data --

	dtmCreationDate		smalldatetime		NOT NULL	CONSTRAINT DF_Corp_Geography_CreateDate DEFAULT (CURRENT_TIMESTAMP),
	uidGeography_GUID	uniqueidentifier	NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_Geography_Geography_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion		rowversion			NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.dimGeography';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.dimGeography: ' + ERROR_MESSAGE();

END CATCH

GO


