
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.dimBusinessUnit')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.dimBusinessUnit
GO

-- dimBusinessUnit Dimension Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this dimension table

BEGIN TRY

	CREATE TABLE Corporate.dimBusinessUnit
	(
	intBusinessUnit_KEY		businessunit_key		NOT NULL 	IDENTITY(1,1) NOT FOR REPLICATION,
	intDataSource_KEY		datasource_key			NOT NULL,
	intDataSourceNumber		datasourcenumber		NOT NULL,
	strDataSourceName		datasourcename			NOT NULL,

	-- Unique Dimension Attributes --

	strBusinessUnitCode		businessunitcode		NOT NULL,
	strBusinessUnitName		organizationname		NOT NULL,
	strBusinessUnitDesc		businessunitdesc		NOT NULL,
	intOrganizationNumber	partynumber				NOT NULL,
	strOrganizationName		organizationname		NOT NULL,
	strParentUnitCode		businessunitcode		NOT NULL,
	strParentUnitName		organizationname		NOT NULL,
	intManagerNumber		partynumber				NOT NULL,
	strManagerName			partyname				NOT NULL,

	-- Standard Dimension Table fare --

	dteFromDate				date					NOT NULL	CONSTRAINT DF_Corp_BusinessUnit_FromDate DEFAULT (CURRENT_TIMESTAMP),
	dteThruDate				date					NULL,
	blnCurrentFlag			bit						NOT NULL	CONSTRAINT DF_Corp_BusinessUnit_CurrentFlag DEFAULT(1),

	-- Audit / Meta Data --

	binHashSCDType1			scdhashtype				NOT NULL	CONSTRAINT DF_Corp_BusinessUnit_HashSCDType1 DEFAULT(0x0),
	binHashSCDType2			scdhashtype				NOT NULL	CONSTRAINT DF_Corp_BusinessUnit_HashSCDType2 DEFAULT(0x0),
	dteUpdatedDate			date					NOT NULL	CONSTRAINT DF_Corp_BusinessUnit_UpdatedDate DEFAULT (CURRENT_TIMESTAMP),
	uidBusinessUnit_GUID	uniqueidentifier		NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_BusinessUnit_BusinessUnit_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion			rowversion				NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.dimBusinessUnit';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.dimBusinessUnit: ' + ERROR_MESSAGE();

END CATCH

GO


