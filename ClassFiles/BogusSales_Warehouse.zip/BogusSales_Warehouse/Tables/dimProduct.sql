
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.dimProduct')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.dimProduct
GO

-- dimProduct Dimension Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.08	Jeffrey Schenk	Original creation of this dimension table

BEGIN TRY

	CREATE TABLE Corporate.dimProduct
	(
	intProduct_KEY			product_key				NOT NULL 	IDENTITY(1,1),

	-- Source System Meta Data --

	intDataSource_KEY		datasource_key			NOT NULL,	-- for system synchronization use (not end user presented)
	intDataSourceNumber		datasourcenumber		NOT NULL,	-- for end user presentation
	strDataSourceName		datasourcename			NOT NULL,	-- denormalized display attribute (doing what dim tables do)

	-- Unique Dimension Attributes --

	strProductCode			productcode			NOT NULL,
	strProductName			productname			NOT NULL,
	strProductCategoryCode	productcategorycode	NOT NULL,
	strProductCategoryName	productcategoryname	NOT NULL,
	strProductCategoryDesc	standarddesc		NOT NULL,
	strProductDesc			standarddesc		NOT NULL,
	strUnitOfIssue			unitofissue			NOT NULL,
	strUnitOfIssueDesc		unitofissuedesc		NULL,
	curUnitPrice			money				NOT NULL,

	-- Standard Dimension Table fare --

	dteFromDate				date					NOT NULL	CONSTRAINT DF_Corp_Product_FromDate DEFAULT (CURRENT_TIMESTAMP),
	dteThruDate				date					NULL,
	blnCurrentFlag			bit						NOT NULL	CONSTRAINT DF_Corp_Product_CurrentFlag DEFAULT(1),

	-- Audit / Meta Data --

	binHashSCDType1			scdhashtype				NOT NULL	CONSTRAINT DF_Corp_Product_HashSCDType1 DEFAULT(0x0),
	binHashSCDType2			scdhashtype				NOT NULL	CONSTRAINT DF_Corp_Product_HashSCDType2 DEFAULT(0x0),
	dteUpdatedDate			date					NOT NULL	CONSTRAINT DF_Corp_Product_UpdatedDate DEFAULT (CURRENT_TIMESTAMP),
	uidProduct_GUID			uniqueidentifier		NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_Product_Product_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion			rowversion				NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.dimProduct';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.dimProduct: ' + ERROR_MESSAGE();

END CATCH

GO


