
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.dimParty')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.dimParty
GO

-- dimParty Dimension Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this dimension table

BEGIN TRY

	CREATE TABLE Corporate.dimParty
	(
	intParty_KEY		party_key			NOT NULL 	IDENTITY(1,1),

	-- Source System Meta Data --

	intDataSource_KEY	datasource_key		NOT NULL,	-- for system synchronization use (not end user presented)
	intDataSourceNumber	datasourcenumber	NOT NULL,	-- for end user presentation
	strDataSourceName	datasourcename		NOT NULL,	-- denormalized display attribute (doing what dim tables do)

	-- Unique Dimension Attributes --

	intPartyNumber		partynumber			NOT NULL,
	strPartyType		varchar(1)			NOT NULL,
	strPartyName		varchar(113)		NOT NULL,
	strPartyStatus		char(1)				NOT NULL	CONSTRAINT DF_Corp_Parties_PartyStatus DEFAULT ('A')
														CONSTRAINT CK_Corp_Parties_PartyStatus CHECK (strPartyStatus IN ('A', 'D')),
														-- Active/Alive, Defunct/Deceased
	strCreditStatus		char(1)				NOT NULL	CONSTRAINT DF_Corp_Parties_CreditStatus DEFAULT ('C')
														CONSTRAINT CK_Corp_Parties_CreditStatus CHECK (strCreditStatus IN ('C', 'T', 'H', 'B')),
														-- C=Cash, T=Terms, H=Hold, B=Block
	strPronunciation	pronunciation		NULL,
	strReferralSource	referralsource		NULL,

	-- Standard Dimension Table fare --

	dteFromDate			date				NOT NULL	CONSTRAINT DF_Corp_Party_FromDate DEFAULT (CURRENT_TIMESTAMP),
	dteThruDate			date				NULL,
	blnCurrentFlag		bit					NOT NULL	CONSTRAINT DF_Corp_Party_CurrentFlag DEFAULT(1),

	-- Audit / Meta Data --

	binHashSCDType1		scdhashtype			NOT NULL	CONSTRAINT DF_Corp_Party_HashSCDType1 DEFAULT(0x0),
	binHashSCDType2		scdhashtype			NOT NULL	CONSTRAINT DF_Corp_Party_HashSCDType2 DEFAULT(0x0),
	dteUpdatedDate		date				NOT NULL	CONSTRAINT DF_Corp_Party_UpdatedDate DEFAULT (CURRENT_TIMESTAMP),
	uidParty_GUID		uniqueidentifier	NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_Party_Party_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion		rowversion			NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.dimParty';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.dimParty: ' + ERROR_MESSAGE();

END CATCH

GO


