
-- Delete any pre-existing occurrence of this table

IF EXISTS(	SELECT * FROM sys.objects 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.tblDataSources')) 
			AND ([type] = N'U')
	) DROP TABLE Corporate.tblDataSources
GO

-- tblDataSources Table

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2007.08.19	Jeffrey Schenk	Original creation of this table

BEGIN TRY

	CREATE TABLE Corporate.tblDataSources
	(
	intDataSource_KEY	datasource_key		NOT NULL,
	intDataSourceNumber	datasourcenumber	NOT NULL,
	strDataSourceName	datasourcename		NOT NULL,
	strDescription		standarddesc		NULL,

	-- Audit / Meta Data --

	dtmCreationDate		smalldatetime		NOT NULL	CONSTRAINT DF_Corp_DataSources_CreateDate DEFAULT (CURRENT_TIMESTAMP),
	strCreatedBy		username			NOT NULL	CONSTRAINT DF_Corp_DataSources_CreatedBy DEFAULT (SYSTEM_USER),
	dtmLastModified		smalldatetime		NOT NULL	CONSTRAINT DF_Corp_DataSources_ModifyDate DEFAULT (CURRENT_TIMESTAMP),
	strModifiedBy		username			NOT NULL	CONSTRAINT DF_Corp_DataSources_ModifiedBy DEFAULT (SYSTEM_USER),
	uidDataSource_GUID	uniqueidentifier	NOT NULL	ROWGUIDCOL CONSTRAINT DF_Corp_DataSources_DataSource_GUID DEFAULT (NEWSEQUENTIALID()),
	binRowVersion		rowversion			NOT NULL
	) ON [DEFAULT]
	WITH
	(
	DATA_COMPRESSION = NONE
	);

	PRINT 'Created table Corporate.tblDataSources';

END TRY
BEGIN CATCH

	PRINT 'ERROR: Could not create table Corporate.tblDataSources: ' + ERROR_MESSAGE();

END CATCH

GO


