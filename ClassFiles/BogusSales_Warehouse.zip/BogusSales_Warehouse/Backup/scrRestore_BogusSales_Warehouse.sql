


RESTORE DATABASE BogusSales_Warehouse FROM DISK = '\\DataSchenk.com\Shares\DevServer\BackupsSQL\BogusSales_Warehouse.bak'
WITH MOVE 'BogusSales_Warehouse_Sys' TO 'C:\DataSchenk\SqlData\BogusSales_Warehouse\BogusSales_Warehouse_Sys.mdf',
MOVE 'BogusSales_Warehouse_Data' TO 'C:\DataSchenk\SqlData\BogusSales_Warehouse\BogusSales_Warehouse_Data.ndf',
MOVE 'BogusSales_Warehouse_Log' TO 'C:\DataSchenk\SqlData\BogusSales_Warehouse\BogusSales_Warehouse_Log.ldf',
REPLACE;
GO