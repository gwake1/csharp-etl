

BACKUP DATABASE BogusSales_Warehouse TO DISK = '\\DataSchenk.com\Shares\DevServer\BackupsSQL\BogusSales_Warehouse.bak' WITH INIT;