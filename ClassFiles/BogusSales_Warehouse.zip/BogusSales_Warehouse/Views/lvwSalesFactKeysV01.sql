
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwSalesFactKeysV01')) 
			
	) DROP VIEW Corporate.lvwSalesFactKeysV01
GO

-- lvwSalesFactKeysV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwSalesFactKeysV01

WITH ENCRYPTION

AS

SELECT

	-- Surrogate Key Fields --

	BUnits.intBusinessUnit_KEY,
	Dates.intDate_KEY,
	Prods.intProduct_KEY,
	Shippers.intShipper_KEY,
	Stores.intStore_KEY,
	Custs.intParty_KEY AS intCustomerParty_KEY,
	Reps.intParty_KEY AS intSalesRepParty_KEY,

	-- Degenerate Facts --

	Sales.intOrderNumber,

	-- Measures --

	Sales.intQuantity,
	Sales.curUnitPrice

FROM
	(((((((BogusSales_Live.Corporate.lvwOLTPSalesFactsV01 AS Sales

	INNER JOIN Corporate.dimBusinessUnit AS BUnits
	ON (Sales.strBusinessUnitCode = BUnits.strBusinessUnitCode)
	AND (1 = BUnits.blnCurrentFlag))

	INNER JOIN Corporate.dimDate AS Dates
	ON (Sales.dteOrderDate = Dates.dteCalendarDate)
	AND (1 = Dates.blnCurrentFlag))

	INNER JOIN Corporate.dimProduct AS Prods
	ON (Sales.strProductCode = Prods.strProductCode)
	AND (1 = Prods.blnCurrentFlag))

	LEFT JOIN Corporate.dimShipper AS Shippers
	ON (Sales.intShipperPartyNumber = Shippers.intPartyNumber)
	AND (1 = Shippers.blnCurrentFlag))

	LEFT JOIN Corporate.dimStore AS Stores
	ON (Sales.intStoreNumber = Stores.intStoreNumber)
	AND (1 = Stores.blnCurrentFlag))

	INNER JOIN Corporate.dimParty AS Custs
	ON (Sales.intCustomerPartyNumber = Custs.intPartyNumber)
	AND (1 = Custs.blnCurrentFlag))

	LEFT JOIN Corporate.dimParty AS Reps
	ON (Sales.intSalesRepPartyNumber = Reps.intPartyNumber)
	AND (1 = Reps.blnCurrentFlag));

GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwSalesFactKeysV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwSalesFactKeysV01', 10, 1);
	END
GO
