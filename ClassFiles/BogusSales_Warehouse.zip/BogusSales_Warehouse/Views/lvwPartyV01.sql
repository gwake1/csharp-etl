
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwPartyV01')) 
			
	) DROP VIEW Corporate.lvwPartyV01
GO

-- lvwPartyV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwPartyV01

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.tblPartyV01') ORDER BY column_id;
		
	SELECT
		
	FROM	
		Corporate.tblPartyV01;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwPartyV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwPartyV01', 10, 1);
	END
GO
