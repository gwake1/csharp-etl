
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'SSS.PPPXXX')) 
			
	) DROP VIEW SSS.PPPXXX
GO

-- PPPXXX View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- YYYY.MM.DD	Jeffrey Schenk	Original creation of this view

CREATE VIEW SSS.PPPXXX

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'SSS.RRRXXX') ORDER BY column_id;
		
	SELECT
		
	FROM	
		SSS.RRRXXX;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view SSS.PPPXXX', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view SSS.PPPXXX', 10, 1);
	END
GO
