
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwBusinessUnitV01')) 
			
	) DROP VIEW Corporate.lvwBusinessUnitV01
GO

-- lvwBusinessUnitV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwBusinessUnitV01

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimBusinessUnit') ORDER BY column_id;
		
	SELECT
		intBusinessUnit_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		strBusinessUnitCode, 
		strBusinessUnitName, 
		strBusinessUnitDesc, 
		intOrganizationNumber, 
		strOrganizationName, 
		strParentUnitCode, 
		strParentUnitName, 
		intManagerNumber, 
		strManagerName, 
		dteFromDate, 
		dteThruDate, 
		blnCurrentFlag, 
		binHashSCDType1, 
		binHashSCDType2, 
		dteUpdatedDate, 
		uidBusinessUnit_GUID, 
		binRowVersion	
	FROM	
		Corporate.dimBusinessUnit;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwBusinessUnitV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwBusinessUnitV01', 10, 1);
	END
GO
