
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwDateV01')) 
			
	) DROP VIEW Corporate.lvwDateV01
GO

-- lvwDateV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwDateV01

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimDate') ORDER BY column_id;
		
	SELECT
		intDate_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		dteCalendarDate, 
		intYearNumber, 
		intSeasonNumber, 
		strSeasonName, 
		intQuarterNumber, 
		strQuarterYearName, 
		strQuarterName, 
		intMonthNumber, 
		strMonthYearName, 
		strMonthName, 
		strMonthDayName, 
		intWeekNumberOfYear, 
		intDayNumberOfBogusSales, 
		intDayNumberOfYear, 
		intDayNumberOfMonth, 
		intDayNumberOfWeek, 
		strDayNameOfWeek, 
		dteFromDate, 
		dteThruDate, 
		blnCurrentFlag, 
		binHashSCDType1, 
		binHashSCDType2, 
		dteUpdatedDate, 
		uidDate_GUID, 
		binRowVersion 
	FROM	
		Corporate.dimDate;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwDateV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwDateV01', 10, 1);
	END
GO
