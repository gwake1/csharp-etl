

CREATE VIEW Corporate.lvwRowCountsV01

AS

	SELECT 'Shippers' AS TableName, COUNT(*) AS intRowCount FROM Corporate.dimShipper UNION
	SELECT 'Date', COUNT(*) FROM Corporate.dimDate UNION
	SELECT 'Product', COUNT(*) FROM Corporate.dimProduct UNION
	SELECT 'BusUnit', COUNT(*) FROM Corporate.dimBusinessUnit UNION
	SELECT 'Store', COUNT(*) FROM Corporate.dimStore UNION
	SELECT 'Party', COUNT(*) FROM Corporate.dimParty UNION
	SELECT 'Supplier', COUNT(*) FROM Corporate.dimSupplier UNION
	SELECT 'Facts', COUNT(*) FROM Corporate.factSales;