
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Maintenance.lvwPartyDimensionV01')) 
			
	) DROP VIEW Maintenance.lvwPartyDimensionV01
GO

-- lvwPartyDimensionV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.11	Jeffrey Schenk	Original creation of this view

CREATE VIEW Maintenance.lvwPartyDimensionV01

WITH ENCRYPTION

AS

	SELECT

		Parties.intPartyNumber,			-- Can Not Change!
		Parties.strPartyType,			-- TYPE 2
		Parties.strPartyName,			-- TYPE 2
		Parties.strPartyStatus,			-- TYPE 2
		Parties.strCreditStatus,		-- TYPE 2
		Parties.strPronunciation,		-- TYPE 1
		Parties.strReferralSource,		-- TYPE 1

		HASHBYTES('SHA1',

						ISNULL(Parties.strPronunciation, '')
						+ '|' + ISNULL(Parties.strReferralSource, '')

				) AS binHashSCDType1,

		HASHBYTES('SHA1',
	
					Parties.strPartyType
					+ '|' + Parties.strPartyName
					+ '|' + Parties.strPartyStatus
					+ '|' + Parties.strCreditStatus

				) AS binHashSCDType2
	FROM
		BogusSales_Live.Corporate.lvwPartiesWideV01 AS Parties;

GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Maintenance.lvwPartyDimensionV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Maintenance.lvwPartyDimensionV01', 10, 1);
	END
GO
