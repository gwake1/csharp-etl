
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwProductV01')) 
			
	) DROP VIEW Corporate.lvwProductV01
GO

-- lvwProductV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwProductV01

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimProduct') ORDER BY column_id;
		
	SELECT
		intProduct_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		strProductCode, 
		strProductName, 
		strProductCategoryCode, 
		strProductCategoryName, 
		strProductCategoryDesc, 
		strProductDesc, 
		strUnitOfIssue, 
		strUnitOfIssueDesc, 
		curUnitPrice, 
		dteFromDate, 
		dteThruDate, 
		blnCurrentFlag, 
		binHashSCDType1, 
		binHashSCDType2, 
		dteUpdatedDate, 
		uidProduct_GUID, 
		binRowVersion	
	FROM	
		Corporate.dimProduct;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwProductV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwProductV01', 10, 1);
	END
GO
