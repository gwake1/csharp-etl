
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwDataSourcesV01')) 
			
	) DROP VIEW Corporate.lvwDataSourcesV01
GO

-- lvwDataSourcesV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2008.02.01	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwDataSourcesV01

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.tblDataSources') ORDER BY column_id;
		
	SELECT
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		strDescription, 
		dtmCreationDate, 
		strCreatedBy, 
		dtmLastModified, 
		strModifiedBy, 
		uidDataSource_GUID, 
		binRowVersion	
	FROM	
		Corporate.tblDataSources;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwDataSourcesV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwDataSourcesV01', 10, 1);
	END
GO
