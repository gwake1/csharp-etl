
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwShipperV01')) 
			
	) DROP VIEW Corporate.lvwShipperV01
GO

-- lvwShipperV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwShipperV01

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimShipper') ORDER BY column_id;
		
	SELECT
		intShipper_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		intPartyNumber, 
		strOrganizationName, 
		strOrgSubTitle, 
		strOrgComponentName, 
		intShipperRank, 
		strShipperRankNote, 
		strVoicePhone, 
		dteFromDate, 
		dteThruDate, 
		blnCurrentFlag, 
		binHashSCDType1, 
		binHashSCDType2, 
		dteUpdatedDate, 
		uidShipper_GUID, 
		binRowVersion 
	FROM	
		Corporate.dimShipper;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwShipperV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwShipperV01', 10, 1);
	END
GO
