
-- Delete any pre-existing occurrence of this view

IF EXISTS(	SELECT * FROM sys.views 
			WHERE ([object_id] = OBJECT_ID(N'Corporate.lvwSupplierV01')) 
			
	) DROP VIEW Corporate.lvwSupplierV01
GO

-- lvwSupplierV01 View

-- Creation, Modification, Maintenance History
---------------	--------------	----------------------------------------------
-- VERSION		PROGRAMMER		DESCRIPTION OF WORK ACCOMPLISHED
---------------	--------------	----------------------------------------------
-- 2012.05.07	Jeffrey Schenk	Original creation of this view

CREATE VIEW Corporate.lvwSupplierV01

WITH ENCRYPTION, SCHEMABINDING

AS
		--Use the following line to generate a column list for this view...
		--SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimSupplier') ORDER BY column_id;
		
	SELECT
		intSupplier_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		intPartyNumber, 
		strOrganizationName, 
		strOrgSubTitle, 
		strOrgComponentName, 
		intSupplierRank, 
		strSupplierRankNote, 
		strVoicePhone, 
		binHashSCDType1, 
		binHashSCDType2, 
		blnCurrentFlag, 
		dteUpdatedDate, 
		dtmCreationDate, 
		uidSupplier_GUID, 
		binRowVersion	
	FROM	
		Corporate.dimSupplier;
GO
	IF(@@ERROR <> 0)
	BEGIN
		RAISERROR('ERROR: Could not create view Corporate.lvwSupplierV01', 11, 1);
	END
	ELSE
	BEGIN
		RAISERROR('Created view Corporate.lvwSupplierV01', 10, 1);
	END
GO
