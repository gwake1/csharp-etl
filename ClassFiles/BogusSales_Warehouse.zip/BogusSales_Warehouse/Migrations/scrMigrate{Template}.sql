SELECT CHAR(9) + [name] + CHAR(9) + '= @' + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'SSS.PPPXXX') ORDER BY column_id;
SELECT CHAR(9) + CHAR(9) + 'XXX.' + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'SSS.PPPXXX') ORDER BY column_id;
SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'SSS.PPPXXX') ORDER BY column_id;

SELECT * INTO SSS.tmpXXX FROM SSS.PPPXXX;

DROP VIEW SSS.lvwXXXV01;


SET IDENTITY_INSERT SSS.PPPXXX ON;

INSERT INTO SSS.PPPXXX
(

)

SELECT


FROM SSS.tmpXXX;


SET IDENTITY_INSERT SSS.PPPXXX OFF;
