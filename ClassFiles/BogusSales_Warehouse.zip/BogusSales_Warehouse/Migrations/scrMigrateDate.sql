SELECT CHAR(9) + [name] + CHAR(9) + '= @' + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimDate') ORDER BY column_id;
SELECT CHAR(9) + CHAR(9) + 'Date.' + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimDate') ORDER BY column_id;
SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimDate') ORDER BY column_id;

SELECT * INTO Corporate.tmpDate FROM Corporate.dimDate;

DROP VIEW Corporate.lvwDateV01;

SET IDENTITY_INSERT Corporate.dimDate ON;

INSERT INTO Corporate.dimDate
(
		intDate_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		dteCalendarDate, 
		intYearNumber, 
		intSeasonNumber, 
		strSeasonName, 
		intQuarterNumber, 
		strQuarterYearName, 
		strQuarterName, 
		intMonthNumber, 
		strMonthYearName, 
		strMonthName, 
		strMonthDayName, 
		intWeekNumberOfYear, 
		intDayNumberOfBogusSales, 
		intDayNumberOfYear, 
		intDayNumberOfMonth, 
		intDayNumberOfWeek, 
		strDayNameOfWeek, 
		dteFromDate, 
		dteThruDate, 
		blnCurrentFlag, 
		binHashSCDType1, 
		binHashSCDType2, 
		dteUpdatedDate, 
		uidDate_GUID
)

SELECT
		intDate_KEY, 
		intDataSource_KEY, 
		intDataSourceNumber, 
		strDataSourceName, 
		dteCalendarDate, 
		intYearNumber, 
		intSeasonNumber, 
		strSeasonName, 
		intQuarterNumber, 
		strQuarterYearName, 
		strQuarterName, 
		intMonthNumber, 
		strMonthYearName, 
		strMonthName, 
		strMonthDayName, 
		intWeekNumberOfYear, 
		intDayNumberOfBogusSales, 
		intDayNumberOfYear, 
		intDayNumberOfMonth, 
		intDayNumberOfWeek, 
		strDayNameOfWeek, 
		dteFromDate, 
		dteThruDate, 
		blnCurrentFlag, 
		binHashSCDType1, 
		binHashSCDType2, 
		dteUpdatedDate, 
		uidDate_GUID

FROM Corporate.tmpDate;


SET IDENTITY_INSERT Corporate.dimDate OFF;
