SELECT CHAR(9) + [name] + CHAR(9) + '= @' + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimProduct') ORDER BY column_id;
SELECT CHAR(9) + CHAR(9) + 'Product.' + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimProduct') ORDER BY column_id;
SELECT CHAR(9) + CHAR(9) + [name] + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'Corporate.dimProduct') ORDER BY column_id;

SELECT * INTO Corporate.tmpProduct FROM Corporate.dimProduct;

DROP VIEW Corporate.lvwProductV01;


SET IDENTITY_INSERT Corporate.dimProduct ON;

INSERT INTO Corporate.dimProduct
(

)

SELECT


FROM Corporate.tmpProduct;


SET IDENTITY_INSERT Corporate.dimProduct OFF;
