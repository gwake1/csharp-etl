


DECLARE @dtmSomeDateTimeOffset datetimeoffset = GETUTCDATE();

SELECT 
	@dtmSomeDateTimeOffset AS DateStoredInOffsetCapableFashion, -- Date captured in an offset capable way...
	CAST(@dtmSomeDateTimeOffset AS Datetime2) AS JustDisplayedAsANormalDate,
	SWITCHOFFSET(@dtmSomeDateTimeOffset, '-05:00') AS CorrectedBackwardsBy5Hours,
	CAST(SWITCHOFFSET(@dtmSomeDateTimeOffset, '-05:00') AS Datetime2) AS CorrectedBackwardsSansOffsetDisplay