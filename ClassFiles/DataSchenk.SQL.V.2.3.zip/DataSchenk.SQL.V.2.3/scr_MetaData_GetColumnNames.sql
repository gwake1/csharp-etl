
	USE Northwind; -- Switch to the Northwind database
	
	-- Dynamically generate column names for a particular table
	-- Best viewed with "Results to Text" (rather than grid) selected

	SELECT CHAR(9) + 'Invs.' + name + ', ' FROM sys.columns WHERE [object_id] = OBJECT_ID(N'dbo.Invoices') ORDER BY column_id;
	
	-- Same code follows, but walked down the page so we can write some comments explaining it...

	SELECT
		CHAR(9)		-- Tab character... indent
		+ 'Invs.'	-- Table name alias
		+ name		-- Colum name field from the sys.columns table
		+ ', '		-- Put a comma after every field name...		 
	FROM 
		sys.columns -- Metadata table carrying information on all columns for all database objects		
	WHERE	 
		[object_id]							-- Unique object_id of the database object to which column maps					
			= OBJECT_ID(					-- Built in function that returns the object_id of a named object
						N'dbo.Invoices'		-- Object you'd like to name -- that is, to find associated columns for
						)		 
	ORDER BY 
		column_id							-- Would otherwise order alphabetically, if you don't specify this created order
		
	-- The ANSI standard way to pull the same column information

	SELECT CHAR(9) + 'Invs.' + COLUMN_NAME + ', ' 
	FROM INFORMATION_SCHEMA.COLUMNS 
	WHERE (TABLE_SCHEMA = N'dbo') AND (TABLE_NAME = N'Invoices') 
	ORDER BY ORDINAL_POSITION