
	USE Northwind; -- Switch to the Northwind database
	
	-- Here we're joining the Employees table right back to itself.
	-- One reference to the table is used to display employee data.
	-- The other reference to the Employees table is to display manager data.
	
	-- You must alias a table name any time it is used multiple times in the same query,
	-- so you should alias it to something that describes its role 
	-- (the use to which you are putting it in the current context),
	-- hence the aliases of Subordinates and Managers
	
	SELECT 
		Subordinates.FirstName,
		Subordinates.LastName,
		Subordinates.HireDate,
		Managers.FirstName + ' ' + Managers.LastName AS ManagerName
	FROM
		(dbo.Employees AS Subordinates

		LEFT JOIN dbo.Employees AS Managers
		ON (Subordinates.ReportsTo = Managers.EmployeeID))
		
	ORDER BY
		Managers.FirstName + ' ' + Managers.LastName;