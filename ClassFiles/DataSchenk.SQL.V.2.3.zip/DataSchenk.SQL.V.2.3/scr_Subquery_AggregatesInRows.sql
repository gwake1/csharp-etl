
	
	USE Northwind; -- Switch to the Northwind database
	
	SELECT
		-- DisplayOrder, --Skip displaying the DisplayOrder field... it is only used to sort in month order
		[MonthName], 
		FreightCharges
		
	FROM
		(
			-- Union all the months together to create a pseudo-table of sorts...
			
				SELECT 1 AS DisplayOrder, 'January (enero)' AS [MonthName], SUM(Freight) AS FreightCharges FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 1
			UNION	
				SELECT 2, 'February (febrero)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 2
			UNION	
				SELECT 3, 'March (marzo)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 3
			UNION
				SELECT 4, 'April (abril)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 4
			UNION
				SELECT 5, 'May (mayo)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 5
			UNION
				SELECT 6, 'June (junio)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 6
			UNION
				SELECT 7, 'July (julio)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 7
			UNION
				SELECT 8, 'August (agosto)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 8
			UNION
				SELECT 9, 'September (septiembre)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 9
			UNION
				SELECT 10, 'October (octubre)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 10
			UNION
				SELECT 11, 'November (noviembre)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 11
			UNION
				SELECT 12, 'December (deciembre)', SUM(Freight) FROM dbo.Orders WHERE DATEPART(Month, OrderDate) = 12
			
		) AS AnnualSales -- Give it a table alias so we can use it as a subquery
		
	ORDER BY
		DisplayOrder; -- Make January show up first... 
		
		
	--if we had sorted by month name we'd have got...
		
		-- April
		-- August
		-- December
		-- February
		-- January
		-- July
		-- June
		-- March
		-- May
		-- November
		-- October
		-- September

