
	USE Northwind; -- Switch to the Northwind database
	
	DECLARE @strTableYouWant varchar(30) = 'Customers';

	DECLARE @strExecuteThisString varchar(255) = 'SELECT * FROM ' + @strTableYouWant;

	EXECUTE(@strExecuteThisString);



